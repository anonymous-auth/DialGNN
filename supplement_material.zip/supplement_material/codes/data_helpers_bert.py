# coding = utf-8

import os
import csv
import sys
import copy
import json
import logging

from transformers.file_utils import is_tf_available
from transformers import BertTokenizer

from utils import read_csv

logger = logging.getLogger(__name__)


class InputExample_Hier(object):
    """
    仅仅将文本转化为类
    A single training/test example for simple sequence classification.
    Args:
        guid: Unique id for the example.
        text_a: string. The untokenized text of the first sequence. For single sequence tasks, only this sequence must be specified.
        text_b: (Optional) string. The untokenized text of the second sequence. Only must be specified for sequence pair tasks.
        label: (Optional) string. The label of the example. This should be specified for train and dev examples, but not for test examples.
    """
    def __init__(self, guid, text_a, text_b=None, label=None, speaker=None):
        self.guid = guid
        self.text_a = text_a
        self.text_b = text_b
        self.label = label
        self.speaker = speaker

    def __repr__(self):
        '''在打印InputExample或者对象时显示__repr__定义的信息'''
        return str(self.to_json_string())

    def to_dict(self):
        """Serializes this instance to a Python dictionary."""
        output = copy.deepcopy(self.__dict__)   #self.__dict__: 包含InputExample对象所有属性及其值的字典
        return output

    def to_json_string(self):
        """Serializes this instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"


class InputFeatures_Hier(object):
    """
    A single set of features of data.
    Args:
        input_ids: Indices of input sequence tokens in the vocabulary.
        attention_mask: Mask to avoid performing attention on padding token indices.
            Mask values selected in ``[0, 1]``:
            Usually  ``1`` for tokens that are NOT MASKED, ``0`` for MASKED (padded) tokens.
        token_type_ids: Segment token indices to indicate first and second portions of the inputs.
        label: Label corresponding to the input
    """

    def __init__(self, input_ids, attention_masks, label, real_token_len, real_conv_len, cls_ids, qmasks, umasks):
        self.input_ids = input_ids
        self.attention_masks = attention_masks
        self.label = label
        self.real_token_len = real_token_len
        self.real_conv_len = real_conv_len
        self.cls_ids = cls_ids
        self.qmasks = qmasks
        self.umasks = umasks

    def __repr__(self):
        return str(self.to_json_string())

    def to_dict(self):
        """Serializes this instance to a Python dictionary."""
        output = copy.deepcopy(self.__dict__)
        return output

    def to_json_string(self):
        """Serializes this instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"


class DataProcessor_Hier(object):
    """Base class for data converters for sequence classification data sets."""

    def get_example_from_tensor_dict(self, tensor_dict):
        """Gets an example from a dict with tensorflow tensors
        Args:
            tensor_dict: Keys and values should match the corresponding Glue
                tensorflow_dataset examples.
        """
        raise NotImplementedError()

    def get_train_examples(self, data_dir):
        """Gets a collection of `InputExample`s for the train set."""
        raise NotImplementedError()

    def get_dev_examples(self, data_dir):
        """Gets a collection of `InputExample`s for the dev set."""
        raise NotImplementedError()

    def get_labels(self):
        """Gets the list of labels for this data set."""
        raise NotImplementedError()

    def tfds_map(self, example):
        """Some tensorflow_datasets datasets are not formatted the same way the GLUE datasets are. 
        This method converts examples to the correct format."""
        if len(self.get_labels()) > 1:
            example.label = self.get_labels()[int(example.label)]
        return example


def convert_examples_to_features_hier(examples, tokenizer: BertTokenizer,
                                      max_len=512,
                                      max_conv_len=50,
                                      max_seq_len=50,
                                      task=None,
                                      label_list=None,
                                      output_mode=None,
                                      pad_on_left=False,
                                      pad_token=0,
                                      pad_token_segment_id=0,
                                      mask_padding_with_zero=True):
    """
    Loads a data file into a list of ``InputFeatures``
    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_seq_len: Maximum example length
        task: GLUE task
        label_list: List of labels. Can be obtained from the processor using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression`` or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it (``1`` for padded values, ``0`` for
            actual values)
    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a ``tf.data.Dataset``
        containing the task-specific features. If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.
    """

    if task is not None:
        processor = processors[task]()
        if label_list is None:
            label_list = processor.get_labels()
            print("Using label list %s for task %s" % (label_list, task))

    label_map = {label: i for i, label in enumerate(label_list)}

    features = []
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            print("Writing example %d" % (ex_index))

        text_a_list = example.text_a.split(' <eou> ')
        text_a = '[CLS]'.join(text_a_list)
        
        # tokenizer
        inputs = tokenizer.encode_plus(text_a, None, add_special_tokens=True, max_length=max_len, truncation=True)
        input_ids = inputs["input_ids"]
        attention_masks = inputs["attention_mask"]
        real_token_len = len(input_ids)
        
        # cls index
        cls_ids = [i for i, input_id in enumerate(input_ids) if input_id == 101]
        cls_ids = cls_ids[:max_conv_len]
        real_conv_len = len(cls_ids)
        umasks = [1] * real_conv_len

        speaker_list = example.speaker.split(' ')[:real_conv_len]
        qmasks = [[1, 0] if speaker == '1' else [0, 1] for speaker in speaker_list]

        # Zero-pad up to the sequence length.
        padding_length = max_len - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_masks = ([0 if mask_padding_with_zero else 1] * padding_length) + attention_masks
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_masks = attention_masks + ([0 if mask_padding_with_zero else 1] * padding_length)

        cls_ids += [-1] * (max_conv_len - real_conv_len)
        umasks += [0] * (max_conv_len - real_conv_len)
        qmasks += [[0, 0]] * (max_conv_len - real_conv_len)

        assert len(input_ids) == max_len, "Error with input length {} vs {}".format(len(input_ids), max_len)
        assert len(attention_masks) == max_len, "Error with input length {} vs {}".format(len(attention_masks), max_len)

        if output_mode == "classification":
            label = label_map[example.label]    #label => index
        elif output_mode == "regression":
            label = float(example.label)
        else:
            raise KeyError(output_mode)

        if ex_index < 5:
            logger.info("*** Example ***")
            logger.info("guid: %s" % (example.guid))
            logger.info("real_token_len: %s" % (real_token_len))
            logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.info("attention_masks: %s" % " ".join([str(x) for x in attention_masks]))
            logger.info("cls_ids: %s" % " ".join([str(x) for x in cls_ids]))
            logger.info("umasks: %s" % " ".join([str(x) for x in umasks]))
            logger.info("qmasks: %s" % " ".join([str(x) for x in qmasks]))
            logger.info("label: %s (id = %d)" % (example.label, label))

        features.append(
                InputFeatures_Hier(input_ids=input_ids,
                              attention_masks=attention_masks,
                              label=label,
                              real_conv_len=real_conv_len,
                              real_token_len=real_token_len,
                              cls_ids=cls_ids,
                              qmasks=qmasks,
                              umasks=umasks))

    return features

class IDProcessor_Hier(DataProcessor_Hier):
    """Processor for the SST-2 data set (GLUE version)."""

    def get_example_from_tensor_dict(self, tensor_dict):
        """See base class."""
        return InputExample_Hier(tensor_dict['idx'].numpy(),
                             ['sentence'].numpy().decode('utf-8'),
                            None,
                            str(tensor_dict['label'].numpy()))

    def get_train_examples(self, data_dir):
        """See base class."""
        return self._create_examples(read_csv(os.path.join(data_dir, "train", "train.csv")), "train")

    def get_dev_examples(self, data_dir):
        """See base class."""
        return self._create_examples(read_csv(os.path.join(data_dir, "dev", "dev.csv")), "dev")

    def get_test_examples(self, data_dir):
        """See base class."""
        return self._create_examples(read_csv(os.path.join(data_dir, "test", "test.csv")), "test")

    def get_labels(self):
        """设置当前数据集的标签"""
        return list(map(str, range(37)))

    def _create_examples(self, lines, set_type):
        """Creates examples for the training/dev/test sets."""
        examples = []
        for (i, line) in enumerate(lines):
            if i == 0:
                continue
            guid = "%s-%s" % (set_type, i)
            label = line[0]
            text_a = line[1]
            speaker = line[2]

            examples.append(InputExample_Hier(guid=guid, text_a=text_a, text_b=None, label=label, speaker=speaker))

        return examples

class InputExample(object):
    """
    仅仅将文本转化为类
    A single training/test example for simple sequence classification.
    Args:
        guid: Unique id for the example.
        text_a: string. The untokenized text of the first sequence. For single sequence tasks, only this sequence must be specified.
        text_b: (Optional) string. The untokenized text of the second sequence. Only must be specified for sequence pair tasks.
        label: (Optional) string. The label of the example. This should be specified for train and dev examples, but not for test examples.
    """
    def __init__(self, guid, text_a, text_b=None, label=None):
        self.guid = guid
        self.text_a = text_a
        self.text_b = text_b
        self.label = label

    def __repr__(self):
        '''在打印InputExample或者对象时显示__repr__定义的信息'''
        return str(self.to_json_string())

    def to_dict(self):
        """Serializes this instance to a Python dictionary."""
        output = copy.deepcopy(self.__dict__)   #self.__dict__: 包含InputExample对象所有属性及其值的字典
        return output

    def to_json_string(self):
        """Serializes this instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"


class InputFeatures(object):
    """
    A single set of features of data.
    Args:
        input_ids: Indices of input sequence tokens in the vocabulary.
        attention_mask: Mask to avoid performing attention on padding token indices.
            Mask values selected in ``[0, 1]``:
            Usually  ``1`` for tokens that are NOT MASKED, ``0`` for MASKED (padded) tokens.
        token_type_ids: Segment token indices to indicate first and second portions of the inputs.
        label: Label corresponding to the input
    """

    def __init__(self, input_ids, attention_mask, label, real_token_len):
        self.input_ids = input_ids
        self.attention_mask = attention_mask
        self.label = label
        self.real_token_len = real_token_len

    def __repr__(self):
        return str(self.to_json_string())

    def to_dict(self):
        """Serializes this instance to a Python dictionary."""
        output = copy.deepcopy(self.__dict__)
        return output

    def to_json_string(self):
        """Serializes this instance to a JSON string."""
        return json.dumps(self.to_dict(), indent=2, sort_keys=True) + "\n"


class DataProcessor(object):
    """Base class for data converters for sequence classification data sets."""

    def get_example_from_tensor_dict(self, tensor_dict):
        """Gets an example from a dict with tensorflow tensors
        Args:
            tensor_dict: Keys and values should match the corresponding Glue
                tensorflow_dataset examples.
        """
        raise NotImplementedError()

    def get_train_examples(self, data_dir):
        """Gets a collection of `InputExample`s for the train set."""
        raise NotImplementedError()

    def get_dev_examples(self, data_dir):
        """Gets a collection of `InputExample`s for the dev set."""
        raise NotImplementedError()

    def get_labels(self):
        """Gets the list of labels for this data set."""
        raise NotImplementedError()

    def tfds_map(self, example):
        """Some tensorflow_datasets datasets are not formatted the same way the GLUE datasets are. 
        This method converts examples to the correct format."""
        if len(self.get_labels()) > 1:
            example.label = self.get_labels()[int(example.label)]
        return example


def convert_examples_to_features(examples, tokenizer,
                                      max_length=512,
                                      task=None,
                                      label_list=None,
                                      output_mode=None,
                                      pad_on_left=False,
                                      pad_token=0,
                                      pad_token_segment_id=0,
                                      mask_padding_with_zero=True):
    """
    Loads a data file into a list of ``InputFeatures``
    Args:
        examples: List of ``InputExamples`` or ``tf.data.Dataset`` containing the examples.
        tokenizer: Instance of a tokenizer that will tokenize the examples
        max_length: Maximum example length
        task: GLUE task
        label_list: List of labels. Can be obtained from the processor using the ``processor.get_labels()`` method
        output_mode: String indicating the output mode. Either ``regression`` or ``classification``
        pad_on_left: If set to ``True``, the examples will be padded on the left rather than on the right (default)
        pad_token: Padding token
        pad_token_segment_id: The segment ID for the padding token (It is usually 0, but can vary such as for XLNet where it is 4)
        mask_padding_with_zero: If set to ``True``, the attention mask will be filled by ``1`` for actual values
            and by ``0`` for padded values. If set to ``False``, inverts it (``1`` for padded values, ``0`` for
            actual values)
    Returns:
        If the ``examples`` input is a ``tf.data.Dataset``, will return a ``tf.data.Dataset``
        containing the task-specific features. If the input is a list of ``InputExamples``, will return
        a list of task-specific ``InputFeatures`` which can be fed to the model.
    """
    if task is not None:
        processor = processors[task]()
        if label_list is None:
            label_list = processor.get_labels()
            logger.info("Using label list %s for task %s" % (label_list, task))

    label_map = {label: i for i, label in enumerate(label_list)}

    features = []
    for (ex_index, example) in enumerate(examples):
        if ex_index % 10000 == 0:
            logger.info("Writing example %d" % (ex_index))

        #inputs: dict
        inputs = tokenizer.encode_plus(
            example.text_a,
            example.text_b,
            add_special_tokens=True,
            max_length=max_length,
            truncation=True
        )
        #input_ids: 输入数据token在词汇表中的索引
        #token_type_ids: 分段token索引，类似segment embedding
        input_ids, attention_mask = inputs["input_ids"], inputs["attention_mask"]
        real_token_len = len(input_ids)

        # Zero-pad up to the sequence length.
        padding_length = max_length - len(input_ids)
        if pad_on_left:
            input_ids = ([pad_token] * padding_length) + input_ids
            attention_mask = ([0 if mask_padding_with_zero else 1] * padding_length) + attention_mask
        else:
            input_ids = input_ids + ([pad_token] * padding_length)
            attention_mask = attention_mask + ([0 if mask_padding_with_zero else 1] * padding_length)

        assert len(input_ids) == max_length, "Error with input length {} vs {}".format(len(input_ids), max_length)
        assert len(attention_mask) == max_length, "Error with input length {} vs {}".format(len(attention_mask), max_length)

        if output_mode == "classification":
            label = label_map[example.label]    #label => index
        elif output_mode == "regression":
            label = float(example.label)
        else:
            raise KeyError(output_mode)


        if ex_index < 5:
            logger.info("*** Example ***")
            logger.info("guid: %s" % (example.guid))
            logger.info("real_token_len: %s" % (real_token_len))
            logger.info("input_ids: %s" % " ".join([str(x) for x in input_ids]))
            logger.info("attention_mask: %s" % " ".join([str(x) for x in attention_mask]))
            logger.info("label: %s (id = %d)" % (example.label, label))

        features.append(
                InputFeatures(input_ids=input_ids,
                              attention_mask=attention_mask,
                              label=label,
                              real_token_len=real_token_len))

    return features


class IDProcessor(DataProcessor):
    """Processor for the SST-2 data set (GLUE version)."""

    def get_example_from_tensor_dict(self, tensor_dict):
        """See base class."""
        return InputExample(tensor_dict['idx'].numpy(),
                            tensor_dict['sentence'].numpy().decode('utf-8'),
                            None,
                            str(tensor_dict['label'].numpy()))

    def get_train_examples(self, data_dir):
        """See base class."""
        return self._create_examples(read_csv(os.path.join(data_dir, "train", "train.csv")), "train")

    def get_dev_examples(self, data_dir):
        """See base class."""
        return self._create_examples(read_csv(os.path.join(data_dir, "dev", "dev.csv")), "dev")

    def get_test_examples(self, data_dir):
        """See base class."""
        return self._create_examples(read_csv(os.path.join(data_dir, "test", "test.csv")), "test")

    def get_labels(self):
        """设置当前数据集的标签"""
        return list(map(str, range(37)))

    def _create_examples(self, lines, set_type):
        """Creates examples for the training/dev/test sets."""
        examples = []
        for (i, line) in enumerate(lines):
            if i == 0:
                continue
            guid = "%s-%s" % (set_type, i)
            label = line[0]
            text_a = "".join(line[1].split(" <eou> "))
            #如有两段文本, 也可以设置text_b
            examples.append(InputExample(guid=guid, text_a=text_a, text_b=None, label=label))

        return examples

tasks_num_labels = {
    "china_mobile_concat": 37,
    "ali_cco_concat": 14,
    "china_mobile_hier": 37,
    "ali_cco_hier": 14,
}

processors = {
    "china_mobile_concat": IDProcessor,
    "ali_cco_concat": IDProcessor,
    "china_mobile_hier": IDProcessor_Hier,
    "ali_cco_hier": IDProcessor_Hier
}

output_modes = {
    "china_mobile_concat": "classification",
    "ali_cco_concat": "classification",
    "china_mobile_hier": "classification",
    "ali_cco_hier": "classification",
}
