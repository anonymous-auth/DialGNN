# coding = utf-8

import argparse
import os

import jieba
from tqdm import tqdm

from utils import Log, write_text


def remove_stopwords(word_list: list, stopword_set: set):
    """去除停用词

    Args:
        word_list (list): [description]
        stopword_set (set): [description]

    Returns:
        [type]: [description]
    """
    if not word_list or not stopword_set:
        return word_list

    word_list = [word for word in word_list if word not in stopword_set]
    return word_list


def prepro_label(data_path, label_dict_path, label_path):
    if not os.path.exists(data_path):
        Log.info("No invalid data: data_path = {}".format(data_path))
        return

    Log.info("Preprocess label start: data_path = {}, label_dict_path = {}, label_path = {}".format(
        data_path, label_dict_path, label_path))
    label_list = []
    label_dict = dict()

    with open(data_path, 'r', encoding='utf-8') as fr:
        cur_conv = []
        for line in tqdm(fr):
            # 过滤空行
            line = line.strip()
            if line:
                if line[0] not in ['1', '2']:
                    tmp_line = line.split('\t')
                    if len(tmp_line) != 3:
                        continue
                    _, cls1, cls2 = tmp_line
                    label = (cls1 + '-' + cls2)
                    if label not in label_dict:
                        label_dict[label] = len(label_dict)
                    label_list.append(label_dict[label])

    with open(label_dict_path, 'w', encoding='utf-8') as fw1:
        for k, v in label_dict.items():
            fw1.write(k + "\t" + str(v) +"\n")

    with open(label_path, 'w', encoding='utf-8') as fw2:
        for label in label_list:
            fw2.write(str(label) + '\n')


def prepro_text(data_path, stopwords_path, conv_path, speaker_path):
    if not os.path.exists(data_path):
        Log.info("No invalid data: data_path = {}".format(data_path))
        return

    Log.info("Preprocess text start: data_path = {}, conv_path = {}".format(
        data_path, conv_path))
    conv_list, speaker_list = [], []
    with open(stopwords_path, 'r', encoding='utf-8') as fr1:
        stopwords_set = {line.strip() for line in fr1}
    
    # split user and service sent if necessary
    mode = 'all'
    if conv_path.find('user') != -1:
        mode = 'user'
    elif conv_path.find('service') != -1:
        mode = 'service'

    with open(data_path, 'r', encoding='utf-8') as fr2:
        cur_conv, cur_speaker_list = [], []
        for line in tqdm(fr2):
            # 过滤空行
            line = line.strip()
            if line:
                if line[0] in ['1', '2']:
                    split_line = line.split('\t')
                    
                    if len(split_line) != 2:
                        continue
                    speaker, dialog_text = split_line
                    
                    if not (mode == 'all' or (mode == 'user' and speaker == '2') or (mode == 'service' and speaker == '1')):
                        continue
                    
                    cur_conv.append(dialog_text)
                    cur_speaker_list.append(speaker)
                    
            # 对话结束
            else:
                conversation = ' <eou> '.join(cur_conv)
                conv_list.append(conversation)
                speaker_list.append(" ".join(cur_speaker_list))

                cur_conv, cur_speaker_list = [], []
    
    write_text(conv_path, conv_list)
    write_text(speaker_path, speaker_list)


def prepro_dataset(data_path, stopwords_path, label_dict_path, label_path, conv_path, speaker_path):
    """对源数据集进行分词处理，并同时将 label 转换为整数

    Args:
        data_path str: 源数据集路径
    """
    if not os.path.exists(data_path):
        Log.info("No invalid data: data_path = {}".format(data_path))
        return

    Log.info("Split word with jieba start.")
    if data_path.find("unlabel") == -1:
        prepro_label(data_path, label_dict_path, label_path)
    prepro_text(data_path, stopwords_path, conv_path, speaker_path)


if __name__ == "__main__":
    data_path = "./data/china_mobile/初赛训练数据/callreason_train_data/callreason.train.fj_and_sh.2w"
    unlabel_data_path = "./data/china_mobile/初赛训练数据/callreason_train_data/unlabeled_data.fj_sh.5w"
    
    stopwords_path = "./baidu_stopwords.txt"

    # label path
    label_dict_path = "./data/china_mobile/concat/other/label_dict.txt"
    label_path = "./data/china_mobile/concat/other/label.txt"
    
    conv_path = "./data/china_mobile/concat/other/conv.txt"
    speaker_path = "./data/china_mobile/concat/other/speaker.txt"

    # unlabel path
    unlabel_conv_path = "./data/china_mobile/concat/other/unlabel_conv.txt"
    unlabel_speaker_path = "./data/china_mobile/concat/other/unlabel_speaker.txt"

    prepro_dataset(data_path, stopwords_path, label_dict_path, label_path, conv_path, speaker_path)
    prepro_dataset(unlabel_data_path, stopwords_path, label_dict_path, label_path, unlabel_conv_path, unlabel_speaker_path)
