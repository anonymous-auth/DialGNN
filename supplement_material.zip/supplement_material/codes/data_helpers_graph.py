# coding = utf-8

from tqdm import tqdm

from utils import FILTER_BERT_TOKEN_LIST, FILTER_BERT_ID_LIST

PAD_ID, SENT_ID, SERVICE_ID, USER_ID, UNK_ID, CLS_ID, SEP_ID = FILTER_BERT_ID_LIST
PAD_TOKEN, SENT_TOKEN, SERVICE_TOKEN, USER_TOKEN, UNK_TOKEN, CLS_TOKEN, SEP_TOKEN = FILTER_BERT_TOKEN_LIST

class Example(object):
    """Class representing a train/val/test example for single-document extractive summarization."""

    def __init__(self, label, sents, speakers, max_len, max_conv_len, sent_max_len, vocab, tokenizer=None, filterids={}):
        """ Initializes the Example, performing tokenization and truncation to produce the encoder, decoder and target sequences, which are stored in self.

        :param article_sents: list(strings) for single document or list(list(string)) for multi-document; one per article sentence. each token is separated by a single space.
        :param abstract_sents: list(strings); one per abstract sentence. In each sentence, each token is separated by a single space.
        :param sent_max_len: int, max length of each sentence
        :param label: int
        :param vocab: Vocabulary object
        """
        # Store the label
        self.label = label
        self.max_len = max_len
        self.max_conv_len = max_conv_len
        self.sent_max_len = sent_max_len

        # Store the original strings
        self.ori_sents = sents[:max_conv_len]
        self.concat_sent = "".join(self.ori_sents)[:self.max_len] # keep data consistent
        self.tokenizer = tokenizer

        # Store speakers
        self.speakers = speakers[:max_conv_len]
        self.filterids = filterids

    def tokenize_and_pad(self):
        # Process the sentences
        # concat data
        self.concat_sent_input = self._tokenize(self.concat_sent, self.max_len)
        self.concat_sent_len = len(self.concat_sent_input)

        # bert data
        self.bert_sent_input = [CLS_ID]
        for sent in self.ori_sents:
            self.bert_sent_input += [SENT_ID] + self._tokenize(sent, self.sent_max_len)
        self.bert_sent_input = self.bert_sent_input[:self.max_len - 1] + [SEP_ID]
        self.bert_atten_mask = [1] * len(self.bert_sent_input)

        # for bert select
        self.bert_sent_token_idxs = [i for i, token_id in enumerate(self.bert_sent_input) if token_id == SENT_ID]
        token_idx_dict = {}
        for i, token_id in enumerate(self.bert_sent_input):
            if token_id not in self.filterids and token_id not in token_idx_dict.keys():
                token_idx_dict[token_id] = i
        self.bert_word_token_idxs = list(token_idx_dict.values()) # fisrt appear
        
        # bert hier sentence input for create graph
        bert_sent_token_idxs = self.bert_sent_token_idxs + [len(self.bert_sent_input) - 1]
        self.bert_hier_sent_input = [self.bert_sent_input[bert_sent_token_idxs[i] + 1: bert_sent_token_idxs[i + 1]] 
                                        for i in range(len(self.bert_sent_token_idxs))] # just for add sent node when use bert

        # hier data
        self.hier_sent_input = [self._tokenize(sent, self.sent_max_len) for sent in self.ori_sents]  # list of word ids; OOVs are represented by the id for UNK token
        self.hier_sent_len = [len(_enc_sent_input) for _enc_sent_input in self.hier_sent_input]
        self.hier_conv_len = len(self.hier_sent_input)
        self.hier_sent_token_idxs = list(range(self.hier_conv_len))

        # pad
        self.concat_sent_input_pad = self._pad(self.concat_sent_input, self.max_len)
        
        self.bert_sent_input_pad = self._pad(self.bert_sent_input, self.max_len)
        self.bert_atten_mask += (self.max_len - len(self.bert_atten_mask)) * [0]
        self.bert_hier_sent_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.bert_hier_sent_input]

        self.hier_sent_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.hier_sent_input]

    def _tokenize(self, sent, max_len, speaker=None):
        inputs = self.tokenizer.encode_plus(
                    text=sent,
                    add_special_tokens=True,
                    max_length=max_len,
                    truncation=True
                )
        input_ids = inputs["input_ids"][1:-1]
        return input_ids

    def _pad(self, sent_input, max_len):
        """
        :param pad_id: int; token pad id
        :return: 
        """
        
        if len(sent_input) < max_len:
            sent_input += [0] * (max_len - len(sent_input))
        else:
            sent_input = sent_input[:max_len]
        return sent_input

class Example2(Example):
    def __init__(self, label, sents, speakers, max_len, max_conv_len, sent_max_len, vocab=None, tokenizer=None, filterids={}):
        """ Initializes the Example, performing tokenization and truncation to produce the encoder, decoder and target sequences, which are stored in self.

        :param article_sents: list(strings) for single document or list(list(string)) for multi-document; one per article sentence. each token is separated by a single space.
        :param abstract_sents: list(strings); one per abstract sentence. In each sentence, each token is separated by a single space.
        :param max_len: int, max length of each sentence
        :param label: int
        :param vocab: Vocabulary object
        """
        super().__init__(label, sents, speakers, max_len, max_conv_len, sent_max_len, vocab, tokenizer, filterids)

    def tokenize_and_pad(self):
        # Process the sentences
        # concat data
        self.concat_sent_input = self._tokenize(self.concat_sent, self.max_len)
        self.concat_sent_len = len(self.concat_sent_input)

        # bert data
        self.bert_sent_input = [CLS_ID]
        for sent, speaker in zip(self.ori_sents, self.speakers):
            special_token = USER_ID if speaker == '2' else SERVICE_ID
            self.bert_sent_input += [special_token] + self._tokenize(sent, self.sent_max_len)
        self.bert_sent_input = self.bert_sent_input[:self.max_len - 1] + [SEP_ID]
        self.bert_atten_mask = [1] * len(self.bert_sent_input)

        # for bert select
        self.bert_sent_token_idxs = [i for i, token_id in enumerate(self.bert_sent_input) if token_id in [USER_ID, SERVICE_ID]]
        self.bert_user_token_idxs = [i for i, token_id in enumerate(self.bert_sent_input) if token_id == USER_ID]
        self.bert_service_token_idxs = [i for i, token_id in enumerate(self.bert_sent_input) if token_id == SERVICE_ID]
        token_idx_dict = {}
        for i, token_id in enumerate(self.bert_sent_input):
            if token_id not in self.filterids and token_id not in token_idx_dict.keys():
                token_idx_dict[token_id] = i
        self.bert_word_token_idxs = list(token_idx_dict.values())
        
        # just for create graph when use bert
        bert_sent_token_idxs = self.bert_sent_token_idxs + [len(self.bert_sent_input) - 1]
        self.bert_hier_sent_input = [self.bert_sent_input[bert_sent_token_idxs[i] + 1: bert_sent_token_idxs[i + 1]] 
                                        for i in range(len(self.bert_sent_token_idxs))]
        self.bert_hu_sent_input = []
        self.bert_hs_sent_input = []
        # merge
        i, j, k = 0, 0, 0
        while i < len(self.bert_user_token_idxs) and j < len(self.bert_service_token_idxs):
            if self.bert_user_token_idxs[i] < self.bert_service_token_idxs[j]:
                self.bert_hu_sent_input.append(self.bert_hier_sent_input[k])
                i += 1
            else:
                self.bert_hs_sent_input.append(self.bert_hier_sent_input[k])
                j += 1
            k += 1
        if i < len(self.bert_user_token_idxs):
            self.bert_hu_sent_input += self.bert_hier_sent_input[k:]
        else:
            self.bert_hs_sent_input += self.bert_hier_sent_input[k:]

        # hier data
        self.hier_sent_input = [self._tokenize(sent, self.sent_max_len) for sent in self.ori_sents]  # list of word ids; OOVs are represented by the id for UNK token
        self.hier_sent_len = [len(_enc_sent_input) for _enc_sent_input in self.hier_sent_input]
        self.hu_sent_enc_input = [sent for sent, speaker in zip(self.hier_sent_input, self.speakers) if speaker == "2"]
        self.hs_sent_enc_input = [sent for sent, speaker in zip(self.hier_sent_input, self.speakers) if speaker == "1"]
        self.hu_sent_token_idx = [i for i, speaker in enumerate(self.speakers) if speaker == "2"]
        self.hs_sent_token_idx = [i for i, speaker in enumerate(self.speakers) if speaker == "1"]

        # pad
        self.concat_sent_input_pad = self._pad(self.concat_sent_input, self.max_len)
        
        self.bert_sent_input_pad = self._pad(self.bert_sent_input, self.max_len)
        self.bert_atten_mask += (self.max_len - len(self.bert_atten_mask)) * [0]
        self.bert_hier_sent_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.bert_hier_sent_input]
        self.bert_hu_sent_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.bert_hu_sent_input]
        self.bert_hs_sent_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.bert_hs_sent_input]
        
        self.hier_sent_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.hier_sent_input]
        self.hu_sent_enc_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.hu_sent_enc_input]
        self.hs_sent_enc_input_pad = [self._pad(sent, self.sent_max_len) for sent in self.hs_sent_enc_input]
