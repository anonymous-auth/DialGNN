# coding = utf-8

import multiprocessing
import os

import jieba
import numpy as np
from gensim.models import KeyedVectors, Word2Vec
from gensim.models.word2vec import LineSentence
from tqdm import tqdm

from preprocess_cm import prepro_text
from utils import Log, pickle_load, pickle_dump, read_text


def word2embed(word2id_path: str, word2vec_path: str, embed_path: str):
    word2id = pickle_load(word2id_path)

    word2vec = load_word2vec(word2vec_path)
    vocab = word2vec.wv.vocab
    dim = word2vec.vectors.shape[-1]
    embedding = np.zeros(shape=(len(word2id), dim))

    Log.info(("Convert word to embedding with pretrain word2vec start:vocab_size = {}, dim = {}, " + 
                "embed_path = {}").format(len(word2id), dim, embed_path))
    for i, word in enumerate(word2id.keys()):
        if word in vocab:
            embedding[i] = word2vec[word]
        else:
            if word != '<pad>':
                embedding[i] = np.random.randn(dim)
    pickle_dump(embedding, embed_path)


def load_word2vec(word2vec_path):
    Log.info("Load pretrain embedding start: word2vec_path = {}".format(word2vec_path))
    word2vec = KeyedVectors.load_word2vec_format(word2vec_path, binary=True)
    return word2vec


def pretrain_word2vec(corpus_path, word2vec_path, sg=0, size=300, window=5, min_count=5):
    if not os.path.exists(corpus_path):
        return
    
    Log.info("Pretrain embedding start: corpus_path = {}, word2vec_path = {}, sg = {}, size = {}, window = {}, min_count = {}".format(
        corpus_path, word2vec_path, sg, size, window, min_count))
    model = Word2Vec(LineSentence(corpus_path), size=300, window=5, min_count=3, workers=multiprocessing.cpu_count() // 2)
    model.wv.save_word2vec_format(word2vec_path, binary=True)


def gen_corpus(label_conv_path, unlabel_conv_path, corpus_path, rebuild=False):
    if not (os.path.exists(label_conv_path) or os.path.exists(unlabel_conv_path)) or (os.path.exists(corpus_path) and not rebuild):
        return
    
    Log.info("Generate corpus for pretraining embedding start: label_conv_path = {}, unlabel_conv_path = {}".format(label_conv_path))
    conv_list = read_text(label_conv_path)
    conv_list += read_text(unlabel_conv_path)

    with open(corpus_path, 'w', encoding='utf-8') as f:
        for conv in conv_list:
            f.write(conv + '\n' + '\n')


if __name__ == "__main__":
    label_conv_path = "./data/china_mobile/concat/other/conv_split.txt"
    unlabel_conv_path = "./data/china_mobile/concat/other/unlabel_conv_split.txt"
    corpus_path = "./data/china_mobile/concat/other/corpus.txt"
    word2vec_path = "./data/china_mobile/concat/other/word2vec_split.pkl"
    
    word2id_path = "./data/china_mobile/concat/other/word2id_split.pkl"
    embed_path = "./embed_split.pkl"
    
    gen_corpus(label_conv_path, unlabel_conv_path, corpus_path)
    pretrain_word2vec(corpus_path, word2vec_path)
    word2embed(word2id_path, word2vec_path, embed_path)
