# coding=utf-8

import os
import sys
import time
from collections import Counter

import dgl
import numpy as np
import torch
from dgl.data.utils import load_graphs, save_graphs
from torch.utils.data import Dataset, TensorDataset
from tqdm import tqdm
from multiprocessing import Pool

from data_helpers_bert import (convert_examples_to_features,
                               convert_examples_to_features_hier, output_modes,
                               processors)
from data_helpers_graph import Example, Example2
from utils import Log, pickle_dump, pickle_load, read_csv, read_json, read_text, FILTER_BERT_ID_LIST, FILTER_BERT_TOKEN_LIST

class IDDataSet(Dataset):
    def __init__(self, label, conv, conv_len):
        super().__init__()
        self.label = label
        self.conv = conv
        self.conv_len = conv_len
        self.len = len(self.conv)

    def __getitem__(self, index):
        """Return Single data"""
        label = torch.tensor(self.label[index], dtype=torch.long)
        conv = torch.tensor(self.conv[index], dtype=torch.long)
        conv_len = torch.tensor(self.conv_len[index], dtype=torch.long)

        return label, conv, conv_len

    def __len__(self):
        return self.len
    
    def collate_fn(self, samples):
        """
        Collate list of data in to batch

        Args:
            data: list of tuple(label, text, conv_len)
        Return:
            Batch of each feature
            - label (LongTensor): [batch_size]
            - conv: [batch_size, max_conv_length]
            - conv_len (LongTensor): [batch_size]
        """
        # Sort by data length (descending order) to use 'pack_padded_sequence'
        samples.sort(key=lambda x: x[2], reverse=True)

        # Separate
        label, conv, conv_len = zip(*samples)
        label = torch.stack(label, dim=0)
        conv = torch.stack(conv, dim=0)
        conv_len = torch.stack(conv_len, dim=0)
        return label, conv, conv_len

class IDDataSet_hier(Dataset):
    def __init__(self, label, conv, conv_len, seq_len):
        self.label = label
        self.conv = conv
        self.conv_len = conv_len
        self.seq_len = seq_len

        self.len = len(self.conv)

    def __getitem__(self, index):
        label = torch.tensor(self.label[index], dtype=torch.long)
        conv = torch.tensor(self.conv[index])
        conv_len = torch.tensor(self.conv_len[index])
        seq_len =torch.tensor( self.seq_len[index])

        return label, conv, conv_len, seq_len

    def __len__(self):
        return self.len
    
    def collate_fn(self, samples):
        """
        Collate list of data in to batch
        Args:
            data: list of tuple(label, conv, conv_len, seq_len, target_length)
        Return:
            Batch of each feature
            - source (LongTensor): [batch_size, max_conversation_length, max_source_length]
            - target (LongTensor): [batch_size, max_conversation_length, max_source_length]
            - conversation_length (np.array): [batch_size]
            - source_length (LongTensor): [batch_size, max_conversation_length]
        """
        # Sort by conversation length (descending order) to use 'pack_padded_sequence'
        samples.sort(key=lambda x: x[2], reverse=True)

        # Separate
        label, conv, conv_len, seq_len = zip(*samples)
        label = torch.stack(label, dim=0)
        conv = torch.stack([seq for _conv in conv for seq in _conv], dim=0)
        conv_len = torch.stack(conv_len, dim=0)
        seq_len = torch.stack([_seq_len for _seq_lens in seq_len for _seq_len in _seq_lens], dim=0)

        return label, conv, conv_len, seq_len

class HeterGraphSet(torch.utils.data.Dataset):
    """ Constructor: Dataset of example(object) for single document summarization"""

    def __init__(self, data_path, max_len, max_conv_len, sent_max_len, 
                        w2s_path, w2c_path, filter_word_path, vocab, tokenizer, 
                        hg_base_model="bert"):
        """ Initializes the ExampleSet with the path of data
        
        :param data_path: string; the path of data
        :param vocab: object;
        :param max_conv_len: int; the maximum sentence number of a document, each example should pad sentences to this length
        :param sent_max_len: int; the maximum token number of a sentence, each sentence should pad tokens to this length
        :param filter_word_path: str; file path, the file must contain one word for each line and the tfidf value must go from low to high (the format can refer to script/lowTFIDFWords.py) 
        :param w2s_path: str; file path, each line in the file contain a json format data (which can refer to the format can refer to script/calw2sTFIDF.py)
        """

        self.data_path = data_path
        self.max_len = max_len
        self.max_conv_len = max_conv_len
        self.sent_max_len = sent_max_len
        self.vocab = vocab
        self.tokenizer = tokenizer
        self.filter_word_path = filter_word_path
        self.hg_base_model = hg_base_model

        Log.info("Creating word2sent from TFIDF file: {}".format(w2s_path))
        self.w2s_tfidf = read_json(w2s_path)
        w2c_tfidf = read_json(w2c_path)
        self.w2c_tfidf = [_w2c_tfidf[str(i)] for i, _w2c_tfidf in enumerate(w2c_tfidf)]

        cached_features_dir = os.path.join(os.path.dirname(self.data_path), 'cached')
        if not os.path.exists(cached_features_dir):
            os.makedirs(cached_features_dir)
        
        self.examples_path = os.path.join(cached_features_dir, 'examples.pkl')
        self.filterwords_path = os.path.join(cached_features_dir, 'filterwords.pkl')
        self.filterids_path = os.path.join(cached_features_dir, 'filterids.pkl')
        self.graphs_path = os.path.join(cached_features_dir, 'graphs.pkl')
        self.graphs4bert_path = os.path.join(cached_features_dir, 'graphs4bert.pkl')
        
        self._load_and_save_filters()
        self._load_and_save_examples()
        self._load_and_save_graphs()
        
        self.size = len(self.example_list)
    
    def _create_examples(self, e):
        example = Example(int(e[0]), e[1].split(' <eou> '), e[2].split(' '), 
                            self.max_len, self.max_conv_len, self.sent_max_len, 
                            self.vocab, self.tokenizer, set(self.filterids))
        example.tokenize_and_pad()
        return example

    def _add_word_node(self, G, input_pad, bert_word_token_idxs):
        wid2nid = {}
        nid2wid = {}
        nid = 0
        for sentid in input_pad:
            for wid in sentid:
                if wid not in self.filterids and wid not in wid2nid.keys():
                    wid2nid[wid] = nid
                    nid2wid[nid] = wid
                    nid += 1

        w_nodes = len(nid2wid)

        G.add_nodes(w_nodes)
        G.set_n_initializer(dgl.init.zero_initializer)
        G.ndata["unit"] = torch.zeros(w_nodes)
        G.ndata["id"] = torch.LongTensor(list(nid2wid.values()))
        G.ndata["dtype"] = torch.zeros(w_nodes)
        if self.hg_base_model == "bert": 
            G.ndata["token_idxs"] = torch.tensor(bert_word_token_idxs, dtype=torch.long)
        
        return wid2nid, nid2wid

    def _create_graph(self, example, w2s_w, w2c_w):
        """Create a graph for each conversation
        
        :param input_pad: list(list); [sentnum, wordnum]
        :param w2s_w: dict(dict) {str: {str: float}}; for each sentence and each word, the tfidf between them
        :return: G: dgl.DGLGraph
            node:
                word: unit=0, dtype=0, id=(int)wordid in vocab
                sentence: unit=1, dtype=1, words=tensor, position=int, label=tensor
            edge:
                word2sent, sent2word:  tffrac=int, dtype=0
        """
        G = dgl.DGLGraph()
        # word token idxs just for bert
        bert_word_token_idxs = example.bert_word_token_idxs
        
        # input
        input_pad = example.bert_hier_sent_input_pad if self.hg_base_model == 'bert' else example.hier_sent_input_pad
        # sent token idxs
        sent_token_idxs = example.bert_sent_token_idxs
        
        input_pad_flat = []
        for _input_pad in input_pad:
            input_pad_flat += _input_pad

        # add word node
        wid2nid, nid2wid = self._add_word_node(G, input_pad, bert_word_token_idxs)
        w_nodes = len(nid2wid)
        
        # add sent nodes
        N = len(input_pad)
        G.add_nodes(N)
        G.ndata["unit"][w_nodes:] = torch.ones(N)
        G.ndata["dtype"][w_nodes:] = torch.ones(N)
        
        sentid2nid = [i + w_nodes for i in range(N)]
        ws_nodes = w_nodes + N

        G.set_e_initializer(dgl.init.zero_initializer)
        for i in range(N):
            c = Counter(input_pad[i])
            sent_nid = sentid2nid[i]
            sent_tfw = w2s_w[str(i)]
            for wid in c.keys():
                if wid in wid2nid.keys() and self.vocab.id2word[wid] in sent_tfw.keys():
                    tfidf = sent_tfw[self.vocab.id2word[wid]]
                    tfidf_box = np.round(tfidf * 9)  # box = 10
                    G.add_edges(wid2nid[wid], sent_nid,
                                data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
                    G.add_edges(sent_nid, wid2nid[wid],
                                data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
        
        # sentence encoding
        G.nodes[sentid2nid].data["input_pad"] = torch.LongTensor(input_pad)  # [N, seq_len]
        G.nodes[sentid2nid].data["position"] = torch.arange(1, N + 1).view(-1, 1).long()  # [N, 1]
        if self.hg_base_model == 'bert':
            G.nodes[sentid2nid].data["token_idxs"] = torch.tensor(sent_token_idxs, dtype=torch.long)

        # add conversaion node
        G.add_nodes(1)
        G.ndata["unit"][ws_nodes:] = torch.ones(1) * 2
        G.ndata["dtype"][ws_nodes:] = torch.ones(1) * 2
        cnode_id = ws_nodes
        n_nodes = ws_nodes + 1

        # add conversation edges
        c = Counter(input_pad_flat)
        for wid, cnt in c.items():
            if wid in wid2nid.keys() and self.vocab.id2word[wid] in w2c_w.keys():
                # w2c c2w
                tfidf = w2c_w[self.vocab.id2word[wid]]
                tfidf_box = np.round(tfidf * 9)  # box = 10
                G.add_edge(wid2nid[wid], cnode_id,
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
                G.add_edge(cnode_id, wid2nid[wid],
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})

        # add converation -> sentence edge for initialize, not compute
        for i in range(N):
            sent_nid = sentid2nid[i]
            G.add_edge(sent_nid, cnode_id, data={"dtype": torch.Tensor([1])})
        
        return G

    def _load_and_save_filters(self):
        if os.path.exists(self.filterwords_path) and os.path.exists(self.filterids_path):
            Log.info("Loading filterwords and filterids from filterwords_path = {}, filterids_path = {}".format(
                self.filterwords_path, self.filterids_path))
            self.filterwords = pickle_load(self.filterwords_path)
            self.filterids = pickle_load(self.filterids_path)
        else:
            filter_words = read_text(self.filter_word_path)
            filter_ids = [self.vocab.word2id[filter_word] for filter_word in filter_words]
            self.filterwords = FILTER_BERT_TOKEN_LIST + filter_words
            self.filterids = FILTER_BERT_ID_LIST + filter_ids
            
            Log.info("Save filterwords and filterids from filterwords_path = {}, filterids_path = {}".format(
                self.filterwords_path, self.filterids_path))
            pickle_dump(self.filterwords, self.filterwords_path)
            pickle_dump(self.filterids, self.filterids_path)

    def _load_and_save_examples(self):
        if os.path.exists(self.examples_path):
            Log.info("Loading examples from examples_path = {}".format(self.examples_path))
            self.example_list = pickle_load(self.examples_path)
        else:
            Log.info("Creating features from: data_path = {}.".format(self.data_path))
            data = read_csv(self.data_path)
            self.example_list = [self._create_examples(line) for line in tqdm(data)]
            pickle_dump(self.example_list, self.examples_path)

    def _load_and_save_graphs(self):
        graphs_path = self.graphs4bert_path if self.hg_base_model == "bert" else self.graphs_path
        if os.path.exists(graphs_path):
            Log.info("Loading graphs from graphs_path = {}".format(graphs_path))
            self.graph_list, _ = load_graphs(graphs_path)
        else:
            Log.info("Creating graphs from: data_path = {}.".format(self.data_path))
            self.graph_list = [self._create_graph(example, w2s_tfidf, w2c_tfidf) for i, (example, w2s_tfidf, w2c_tfidf) in 
                                    tqdm(enumerate(zip(self.example_list, self.w2s_tfidf, self.w2c_tfidf)))]
            save_graphs(graphs_path, self.graph_list)

    def __getitem__(self, index):
        """
        :param index: int; the index of the example
        :return 
            G: graph for the example
            index: int; the index of the example in the dataset
        """
        example = self.example_list[index]
        G = self.graph_list[index]
        # for test
        # w2s_tfidf = self.w2s_tfidf[index]
        # w2c_tfidf = self.w2c_tfidf[index]
        # G = self._create_graph(example, w2s_tfidf, w2c_tfidf)

        label = torch.tensor(example.label, dtype=torch.long)
        bert_sent_input_pad = torch.tensor(example.bert_sent_input_pad, dtype=torch.long)
        bert_atten_mask = torch.tensor(example.bert_atten_mask, dtype=torch.long)
        hier_sent_input_pad = torch.tensor(example.hier_sent_input_pad, dtype=torch.long)
        hier_conv_len = torch.tensor(example.hier_conv_len, dtype=torch.long)
        hier_sent_len = torch.tensor(example.hier_sent_len, dtype=torch.long)

        return label, bert_sent_input_pad, bert_atten_mask, hier_sent_input_pad, hier_conv_len, hier_sent_len, G

    def __len__(self):
        return self.size

    def collate_fn(self, samples):
        '''
        :param batch: (G, input_pad)
        :return: 
        '''
        # label, input_id, conv_len or mask(bert), seq_len or None(bert)
        labels, bert_sent_input_pad, bert_atten_mask, hier_sent_input_pad, hier_conv_len, hier_sent_len, graphs = zip(*samples)
        
        # sort by sentence number descend
        graph_len = [len(g.filter_nodes(lambda nodes: nodes.data["unit"] == 1)) for g in graphs]  # sent node of graph
        _, sorted_index = torch.sort(torch.LongTensor(graph_len), dim=0, descending=True)
        labels = [labels[idx] for idx in sorted_index]
        bert_sent_input_pad = [bert_sent_input_pad[idx] for idx in sorted_index]
        bert_atten_mask = [bert_atten_mask[idx] for idx in sorted_index]
        hier_sent_input_pad = [hier_sent_input_pad[idx] for idx in sorted_index]
        hier_conv_len = [hier_conv_len[idx] for idx in sorted_index]
        hier_sent_len = [hier_sent_len[idx] for idx in sorted_index]

        labels = torch.stack(labels, dim=0)
        bert_sent_input_pad = torch.stack(bert_sent_input_pad, dim=0)
        bert_atten_mask = torch.stack(bert_atten_mask, dim=0)
        hier_sent_input_pad = torch.stack([sent for conv in hier_sent_input_pad for sent in conv], dim=0)
        hier_conv_len = torch.stack(hier_conv_len, dim=0)
        hier_sent_len = torch.stack([seq_len for seq_lens in hier_sent_len for seq_len in seq_lens], dim=0)
        graphs = dgl.batch([graphs[idx] for idx in sorted_index])
        
        return labels, bert_sent_input_pad, bert_atten_mask, hier_sent_input_pad, hier_conv_len, hier_sent_len, graphs

class HeterGraphSet2(HeterGraphSet):
    """ Constructor: Dataset of example(object) for multiple document summarization"""
    def __init__(self, data_path, max_len, max_conv_len, sent_max_len, 
                        w2s_path, w2c_path, filter_word_path, vocab, tokenizer, 
                        hg_base_model="bert"):
        """ Initializes the ExampleSet with the path of data

        :param data_path: string; the path of data
        :param vocab: object;
        :param max_conv_len: int; the maximum sentence number of a conversaiton, each example should pad sentences to this length
        :param sent_max_len: int; the maximum token number of a sentence, each sentence should pad tokens to this length
        :param filter_word_path: str; file path, the file must contain one word for each line and the tfidf value must go from low to high (the format can refer to script/lowTFIDFWords.py) 
        :param w2s_path: str; file path, each line in the file contain a json format data (which can refer to the format can refer to script/calw2sTFIDF.py)
        :param w2c_path: str; file path, each line in the file contain a json format data (which can refer to the format can refer to script/calw2dTFIDF.py)
        """
        super().__init__(data_path, max_len, max_conv_len, sent_max_len, w2s_path, w2c_path, filter_word_path, vocab, tokenizer, hg_base_model)
        Log.info("Creating word2conversation from TFIDF file: {}".format(w2c_path))
        cached_features_dir = os.path.join(os.path.dirname(self.data_path), 'cached')
        if not os.path.exists(cached_features_dir):
            os.makedirs(cached_features_dir)
        
        self.examples_path = os.path.join(cached_features_dir, 'examples2.pkl')
        self.filterwords_path = os.path.join(cached_features_dir, 'filterwords2.pkl')
        self.filterids_path = os.path.join(cached_features_dir, 'filterids2.pkl')
        self.graphs_path = os.path.join(cached_features_dir, 'graphs2.pkl')
        
    def _create_examples(self, e):
        example = Example2(int(e[0]), e[1].split(' <eou> '), e[2].split(' '), 
                            self.max_len, self.max_conv_len, self.sent_max_len, 
                            self.vocab, self.tokenizer, set(self.filterids))
        example.tokenize_and_pad()
        return example

    def _create_graph(self, example, w2s_w, w2c_w):
        """ Create a graph for each document

        :param input_pad: list(list); [sentnum, wordnum]
        :param w2s_w: dict(dict) {str: {str: float}}, for each sentence and each word, the tfidf between them
        :return: G: dgl.DGLGraph
            node:
                word: unit=0, dtype=0, id=(int)wordid in vocab
                sentence: unit=1, dtype=1, words=tensor, position=int, label=tensor
                document: unit=1, dtype=2
            edge:
                word2sent, sent2word: tffrac=int, dtype=0
                word2doc, doc2word: tffrac=int, dtype=0
                sent2doc: dtype=2
        """
        
        G = dgl.DGLGraph()
        
        # word token_idx just for bert
        bert_word_token_idxs = example.bert_word_token_idxs

        # input_pad
        input_pad = example.bert_hier_sent_input_pad if self.hg_base_model == 'bert' else example.hier_sent_input_pad
        
        # user and service
        user_input_pad = example.bert_hu_sent_input_pad if self.hg_base_model == 'bert' else example.hu_sent_enc_input_pad
        service_input_pad = example.bert_hs_sent_input_pad if self.hg_base_model == 'bert' else example.hs_sent_enc_input_pad

        # sent token idxs
        user_token_idxs = example.bert_user_token_idxs if self.hg_base_model == "bert" else example.hier_user_token_idxs
        service_token_idxs = example.bert_service_token_idxs if self.hg_base_model == "bert" else example.hier_service_token_idxs
        
        input_pad_flat = []
        for _input_pad in input_pad:
            input_pad_flat += _input_pad

        # add word nodes
        wid2nid, nid2wid = self._add_word_node(G, input_pad, bert_word_token_idxs)
        w_nodes = len(nid2wid)
        
        # add user sent nodes
        N1 = len(user_input_pad)
        G.add_nodes(N1)
        G.ndata["unit"][w_nodes:] = torch.ones(N1)
        G.ndata["dtype"][w_nodes:] = torch.ones(N1)
        user_sentid2nid = [i + w_nodes for i in range(N1)]
        wu_nodes = w_nodes + N1

        G.nodes[user_sentid2nid].data["input_pad"] = torch.LongTensor(user_input_pad)  # [N1, seq_len]
        G.nodes[user_sentid2nid].data["position"] = torch.arange(1, N1 + 1).view(-1, 1).long()  # [N, 1]
        G.nodes[user_sentid2nid].data["token_idxs"] = torch.tensor(user_token_idxs, dtype=torch.long)

        # add user sent edges
        user_w2s_w = w2s_w["user"]
        for i in range(N1):
            c = Counter(user_input_pad[i])
            user_sent_nid = user_sentid2nid[i]
            user_sent_tfw = user_w2s_w[str(i)]
            for wid, cnt in c.items():
                if wid in wid2nid.keys() and self.vocab.id2word[wid] in user_sent_tfw.keys():
                    tfidf = user_sent_tfw[self.vocab.id2word[wid]]
                    tfidf_box = np.round(tfidf * 9)  # box = 10
                    # user w2s s2w
                    G.add_edge(wid2nid[wid], user_sent_nid,
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
                    G.add_edge(user_sent_nid, wid2nid[wid],
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})

        # add service nodes
        N2 = len(service_input_pad)
        G.add_nodes(N2)
        G.ndata["unit"][wu_nodes:] = torch.ones(N2)
        G.ndata["dtype"][wu_nodes:] = torch.ones(N2) * 2
        service_sent2nid = [i + wu_nodes for i in range(N2)]
        ws_nodes = wu_nodes + N2

        G.nodes[service_sent2nid].data["input_pad"] = torch.LongTensor(service_input_pad)  # [2, seq_len]
        G.nodes[service_sent2nid].data["position"] = torch.arange(1, N2 + 1).view(-1, 1).long()  # [N, 1]
        G.nodes[service_sent2nid].data["token_idxs"] = torch.tensor(service_token_idxs, dtype=torch.long)
        
        # add service sent edges
        service_w2s_w = w2s_w["service"]
        for i in range(N2):
            c = Counter(service_input_pad[i])
            service_sent_nid = service_sent2nid[i]
            service_sent_tfw = service_w2s_w[str(i)]
            for wid, cnt in c.items():
                if wid in wid2nid.keys() and self.vocab.id2word[wid] in service_sent_tfw.keys():
                    # service w2s s2w
                    tfidf = service_sent_tfw[self.vocab.id2word[wid]]
                    tfidf_box = np.round(tfidf * 9)  # box = 10
                    G.add_edge(wid2nid[wid], service_sent_nid,
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
                    G.add_edge(service_sent_nid, wid2nid[wid],
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})

        # add conversaion node
        G.add_nodes(1)
        G.ndata["unit"][ws_nodes:] = torch.ones(1) * 2
        G.ndata["dtype"][ws_nodes:] = torch.ones(1) * 3
        cnode_id = ws_nodes
        w_nodes = ws_nodes + 1

        # add conversation edges
        c = Counter(input_pad_flat)
        for wid, cnt in c.items():
            if wid in wid2nid.keys() and self.vocab.id2word[wid] in w2c_w.keys():
                # w2c c2w
                tfidf = w2c_w[self.vocab.id2word[wid]]
                tfidf_box = np.round(tfidf * 9)  # box = 10
                G.add_edge(wid2nid[wid], cnode_id,
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
                G.add_edge(cnode_id, wid2nid[wid],
                            data={"tffrac": torch.LongTensor([tfidf_box]), "dtype": torch.Tensor([0])})
        
        return G

def load_and_cache_examples_hier(args, task, tokenizer, evaluate=False, predict=False):
    ''' For DialogueGCN
    
    args:
        evaluate: False. 若为True，则对dev.csv进行转换
        predict: False. 若为True，则则对test.csv进行转换
    return:
        dataset
    '''
    processor = processors[task]()  #CMProcessor()
    output_mode = output_modes[task]    #classification

    # Load data features from cache or dataset file
    # cached_features_file 为数据集的构造的特征的保存目录
    if evaluate:
        exec_model = 'dev'
    elif predict:
        exec_model = 'test'
    else:
        exec_model = 'train'

    cached_features_file = os.path.join(args.dataset_dir, 'cached_{}_{}_{}_{}_{}'.format(
        exec_model,
        list(filter(None, args.bert_model_name_or_path.split('/'))).pop(),
        str(args.max_conv_len),
        str(args.max_seq_len),
        str(task)))

    if os.path.exists(cached_features_file):
        print("Loading features from cached file {}".format(cached_features_file))
        features = torch.load(cached_features_file)
    else:
        print("Creating features from dataset file at {}".format(args.dataset_dir))
        label_list = processor.get_labels()
        if evaluate:
            examples = processor.get_dev_examples(args.dataset_dir)
        elif predict:
            examples = processor.get_test_examples(args.dataset_dir)
        else:
            examples = processor.get_train_examples(args.dataset_dir)
        features = convert_examples_to_features_hier(examples,
                                                tokenizer,
                                                label_list=label_list,
                                                max_len=args.max_len,
                                                max_conv_len=args.max_conv_len,
                                                max_seq_len=args.max_seq_len,
                                                output_mode=output_mode,
                                                pad_on_left=bool(args.bert_model_type in ['xlnet']),                 # pad on the left for xlnet
                                                pad_token=tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0],
                                                pad_token_segment_id=4 if args.bert_model_type in ['xlnet'] else 0,
        )
        print("Saving features into cached file {}".format(cached_features_file))
        torch.save(features, cached_features_file)

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_masks = torch.tensor([f.attention_masks for f in features], dtype=torch.long)
    all_cls_ids = torch.tensor([f.cls_ids for f in features], dtype=torch.long)
    all_qmasks = torch.tensor([f.qmasks for f in features], dtype=torch.long)
    all_umasks = torch.tensor([f.umasks for f in features], dtype=torch.long)
    all_real_conv_len = torch.tensor([f.real_conv_len for f in features], dtype=torch.long)

    if output_mode == "classification":
        all_labels = torch.tensor([f.label for f in features], dtype=torch.long)
    elif output_mode == "regression":
        all_labels = torch.tensor([f.label for f in features], dtype=torch.float)

    dataset = TensorDataset(all_labels, all_input_ids, all_cls_ids, all_qmasks, all_umasks, all_attention_masks, all_real_conv_len)
    return dataset

def load_and_cache_examples(args, task, tokenizer, evaluate=False, predict=False):
    '''
        将dataset转换为features，并保存在目录cached_features_file中。
    
    args:
        evaluate: False. 若为True，则对dev.csv进行转换
        predict: False. 若为True，则则对test.csv进行转换

    return:
        dataset
    '''

    processor = processors[task]()  #THUNewsProcessor()
    output_mode = output_modes[task]    #classification

    # Load data features from cache or dataset file
    #cached_features_file 为数据集的构造的特征的保存目录
    if evaluate:
        exec_model = 'dev'
    elif predict:
        exec_model = 'test'
    else:
        exec_model = 'train'

    cached_features_file = os.path.join(args.dataset_dir, 'cached_{}_{}_{}_{}'.format(
        exec_model,
        list(filter(None, args.bert_model_name_or_path.split('/'))).pop(),
        str(args.max_len),
        str(task)))

    if os.path.exists(cached_features_file):
        print("Loading features from cached file {}".format(cached_features_file))
        features = torch.load(cached_features_file)
    else:
        print("Creating features from dataset file at {}".format(args.dataset_dir))
        label_list = processor.get_labels()
        if evaluate:
            examples = processor.get_dev_examples(args.dataset_dir)
        elif predict:
            examples = processor.get_test_examples(args.dataset_dir)
        else:
            examples = processor.get_train_examples(args.dataset_dir)
        features = convert_examples_to_features(examples,
                                                tokenizer,
                                                label_list=label_list,
                                                max_length=args.max_len,
                                                output_mode=output_mode,
                                                pad_on_left=bool(args.bert_model_type in ['xlnet']),                 # pad on the left for xlnet
                                                pad_token=tokenizer.convert_tokens_to_ids([tokenizer.pad_token])[0],
                                                pad_token_segment_id=4 if args.bert_model_type in ['xlnet'] else 0,
        )
        print("Saving features into cached file {}".format(cached_features_file))
        torch.save(features, cached_features_file)

    # Convert to Tensors and build dataset
    all_input_ids = torch.tensor([f.input_ids for f in features], dtype=torch.long)
    all_attention_mask = torch.tensor([f.attention_mask for f in features], dtype=torch.long)
    if output_mode == "classification":
        all_labels = torch.tensor([f.label for f in features], dtype=torch.long)
    elif output_mode == "regression":
        all_labels = torch.tensor([f.label for f in features], dtype=torch.float)
 
    dataset = TensorDataset(all_labels, all_input_ids, all_attention_mask)
    return dataset
