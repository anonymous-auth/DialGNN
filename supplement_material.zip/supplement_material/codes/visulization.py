# coding = utf-8

import matplotlib.pyplot as plt

def my_plot(x1, y1, x2, y2, y1_legend, y2_legend, title, xlabel, ylabel, figure_name):
    plt.title(title)
    plt.xticks()
    plt.xlabel(xlabel)
    plt.ylabel(ylabel)
    a1, = plt.plot(x1, y1)
    a2, = plt.plot(x2, y2)
    plt.legend(handles=[a1, a2],labels=[y1_legend, y2_legend])
    plt.savefig(figure_name)

step = range(1, 11)
# step = [str(_step) + 'k' for _step in step]
# step = [_step * 500 for _step in step]
step = [_step * 1000 for _step in step] # bert every 1000 step evaluate 

cnn_lstm_acc = [12.5, 21.1, 25.5, 31.8, 38, 42.5, 45.5, 46.2, 46.5, 46.4]
cnn_lstm_p = [1.2, 4.3, 10.2, 12.3, 18, 17.3, 20.1, 19.8, 21.8, 23.6]
cnn_lstm_r = [3.3, 6.6, 13.5, 16.6, 19.5, 21.7, 21.9, 21.5, 21.9, 22.9]
cnn_lstm_f1 = [1.6, 4.45, 7.33, 11.2, 14.6, 17.3, 19.8, 20.2, 20.5, 21.2]
cnn_lstm_f1_alpha = [1.9, 5.4, 9.9, 13, 17.1, 18.6, 21, 21, 24.2, 25.3]

hged_cl_acc = [18.6, 39.8, 51.5, 52.7, 53.4, 54.2, 54.1, 52.6, 51.7, 52.0]
hged_cl_p = [6, 18.1, 30.8, 38.5, 40.7, 41, 46.1, 40.2, 37.4, 38.7]
hged_cl_r = [5.7, 17.4, 28.1, 31.7, 34.7, 36.2, 38.2, 36.2, 32.5, 35.5]
hged_cl_f1 = [4.3, 14.4, 26.4, 31.7, 36.4, 38.9, 36.2, 32.8, 35.1, 36.8]
hged_cl_f1_alpha = [5.8, 17.6, 29.2, 34.2, 37, 38, 41.1, 37.8, 34.4, 36.7]

han_acc = [10.3, 12.3, 20.5, 46.2, 56.8, 59.9, 62.5, 61.8, 62.7, 62.3]
han_p = [0.3, 0.8, 5.4, 19.8, 29.8, 34.3, 49.2, 43.4, 45.7, 45.5]
han_r = [3, 3.1, 6.6, 19.5, 29.1, 32.8, 35.2, 38.3, 37.2, 40.7]
han_f1 = [0.5, 0.8, 4.2, 18.3, 28.5, 32.3, 36.5, 38.6, 37.7, 40.3]
han_f1_alpha = [0.7, 1.5, 6, 19.6, 29.4, 33.4, 39.8, 40.2, 40.3, 42.5]

hged_han_acc = [27, 45, 53.5, 60.1, 63.1, 62.4, 63.1, 62.9, 62.5, 63]
hged_han_p = [13.2, 23, 33.8, 39.6, 50.3, 47.6, 48.5, 49, 48.3, 48.5]
hged_han_r = [11.9, 20.2, 30, 35, 46.1, 42.2, 38.9, 46.4, 37.1, 44.1]
hged_han_f1 = [10.2, 18.9, 28.8, 34.3, 44.9, 41.8, 40.1, 44.7, 43.5, 41.3]
hged_han_f1_alpha = [12.4, 21.3, 31.4, 36.8, 47.7, 44.3, 44.9, 47.5, 46.7, 44.8]

bert_acc = [56.1, 61.3, 67.1, 65.1, 66.6, 67.3, 67.6, 68.6, 69.1, 69.2]
hged_bert_acc = [59.2, 65.3, 67.1, 68.3, 69.9, 68.9, 70.1, 69.4, 69.3, 69.6]

# my_plot(step, han_acc, hged_han_acc, 'Han', "Han+HGED", 'Accuracy', 'Step', 'Score', './statistic/visulize/cm_han_acc.png')
# my_plot(step, han_p, hged_han_p, 'Han', "Han+HGED", 'Precision', 'Step', 'Score', './statistic/visulize/cm_han_prec.png')
# my_plot(step, han_r, hged_han_r, 'Han', "Han+HGED", 'Recall', 'Step', 'Score', './statistic/visulize/cm_han_recall.png')
# my_plot(step, han_f1, hged_han_f1, 'Han', "Han+HGED", 'F1', 'Step', 'Score', './statistic/visulize/cm_han_f1.png')
# my_plot(step, han_f1_alpha, hged_han_f1_alpha, 'Han', "Han+HGED", '$F_{\\alpha}$', 'Step', 'Score', './statistic/visulize/cm_han_f1_alpha.png')

# my_plot(step, cnn_lstm_acc, hged_cl_acc, 'Cnn_lstm', "Cnn_lstm+HGED", 'Accuracy', 'Step', 'Score', './statistic/visulize/cm_cl_acc.png')
# my_plot(step, cnn_lstm_p, hged_cl_p, 'Cnn_lstm', "Cnn_lstm+HGED", 'Precision', 'Step', 'Score', './statistic/visulize/cm_cl_prec.png')
# my_plot(step, cnn_lstm_r, hged_cl_r, 'Cnn_lstm', "Cnn_lstm+HGED", 'Recall', 'Step', 'Score', './statistic/visulize/cm_cl_recall.png')
# my_plot(step, cnn_lstm_f1, hged_cl_f1, 'Han', "Cnn_lstm+HGED", 'F1', 'Step', 'Score', './statistic/visulize/cm_cl_f1.png')
# my_plot(step, cnn_lstm_f1_alpha, hged_cl_f1_alpha, 'Cnn_lstm', "Cnn_lstm+HGED", '$F_{\\alpha}$', 'Step', 'Score', './statistic/visulize/cm_cl_f1_alpha.png')

# my_plot(step, bert_acc, hged_bert_acc, 'Bert', "Bert+HGED", 'Accuracy', 'Step', 'Score', './statistic/visulize/cm_bert_acc.png')


step = list(range(10, 105, 5))

baseline_015 = [26.27, 26.56, 26.72, 26.59, 27.1, 27.27, 27.17, 27.27, 27.18, 27.08, 26.97]
dynamic_015 = [26.08, 26.77, 26.77, 26.63, 27.24, 26.96, 27.48, 27.5, 27.62, 27.32, 27.34]

# baseline_05 = [25.89, 26.26, 26.4, 26.18, 26.92, 26.82, 26.8, 27.14, 27.03, 27.14, 27.13, 27.36, 27.29, 27.3, 27.25, 27.2, 27.02, 27.4, 27.3]
# dynamic_05 = [26.15, 26.42, 26.47, 26.43, 26.96, 26.91, 27.04, 27.25, 27.2, 27.29, 27.08, 27.03, 27.43, 27.14, 26.92, 27.41, 27.15, 27.55, 27.36]

baseline_05 = [25.89, 26.26, 26.4, 26.18, 26.92, 26.82, 26.8, 27.14, 27.03, 27.14, 27.13]
dynamic_05 = [26.15, 26.42, 26.47, 26.43, 26.96, 26.91, 27.04, 27.25, 27.2, 27.29, 27.18]

# my_plot(step[:len(baseline_015)], baseline_015, step[:len(dynamic_015)], dynamic_015, "Baseline(0.15)", "Dynamic(0.15)", "WMT 14 En-De", "Epoch", "BLEU", "vivi_loss_015.png")
my_plot(step[:len(baseline_05)], baseline_05, step[:len(dynamic_05)], dynamic_05, "Baseline(0.5)", "Dynamic(0.5)", "WMT 14 En-De", "Epoch", "BLEU", "vivi_loss_05.png")
