# coding = utf-8

import argparse
import json
import os

import jieba
from tqdm import tqdm

from utils import Log, TfIdf


def get_data_type(path):
    return path.split("/")[-1]


def main():
    parser = argparse.ArgumentParser()

    parser.add_argument('--data_dir', type=str, default='data/ali_cco/hier/graph/train', help='Source Data Dir')
    parser.add_argument('--use_word', action='store_true', default=False, help="word or char")
    args = parser.parse_args()

    data_type = get_data_type(args.data_dir)
    data_path = os.path.join(args.data_dir, data_type + '.csv')
    
    use_word = args.use_word
    prefix = 'split_' if use_word else ''
    save_path = os.path.join(args.data_dir, data_type + '.' + prefix + 'w2s.tfidf.json')
    Log.info("Save word2sent features of dataset %s to %s" % (args.data_dir, save_path))

    fw = open(save_path, "w", encoding='utf-8')
    with open(data_path, "r", encoding='utf-8') as fr:
        next(fr)
        for line in tqdm(fr):
            _, conv, _ = line.strip().split('\t')
            sents = conv.split(" <eou> ")
            if use_word: sents = [' '.join(list(jieba.cut(sent))) for sent in sents]
            else: sents = [' '.join(list(sent)) for sent in sents]
            tfidf = TfIdf()
            tfidfvector = tfidf.get_tfidfvector(sents)
            fw.write(json.dumps(tfidfvector, ensure_ascii=False) + "\n")


if __name__ == "__main__":
    main()
