#!/bin/env python
#coding:utf-8
#Author:brxx122@gmail.com

import argparse
import json
import os

import jieba
import numpy as np
from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer

from utils import Log, TfIdf

def get_data_type(path):
    return path.split("/")[-1]


def main():
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--data_dir', type=str, default='data/china_mobile/hier/graph/train', help='Source Data Dir')
    parser.add_argument('--use_word', action='store_true', default=False, help="word or char")
    args = parser.parse_args()

    data_type = get_data_type(args.data_dir)
    data_path = os.path.join(args.data_dir, data_type + '.csv')

    use_word = args.use_word
    prefix = 'split_' if use_word else ''
    save_path = os.path.join(os.path.dirname(args.data_dir), prefix + 'filter_words.txt')
    with open('./baidu_stopwords.txt', 'r', encoding='utf-8') as fr1:
        baidu_stopwords_list = [line.strip() for line in fr1 if len(line.strip()) == 1]

    with open(save_path, 'w', encoding='utf-8') as fw1:
        for baidu_stopwords in baidu_stopwords_list:
            fw1.write(baidu_stopwords + '\n')

    # convserations = []
    # with open(data_path, "r", encoding="utf-8") as fr:
    #     next(fr)
    #     for line in fr:
    #         _, conv, _ = line.split('\t')
    #         sents = conv.split(" <eou> ")
    #         if use_word:
    #             sents = [' '.join(list(jieba.cut(sent))) for sent in sents]
    #         else:
    #             sents = [' '.join(list(sent)) for sent in sents]
    #         convserations.append(" ".join(sents))
    
    # tfidf = TfIdf()
    # vectorizer, tfidf_weight = tfidf.get_tfidf_embedding(convserations)
    # Log.info("The number of example is %d, and the TFIDF vocabulary size is %d" % (len(convserations), len(vectorizer.vocabulary_)))
    # word_tfidf = np.array(tfidf_weight.mean(0))
    # del tfidf_weight
    # word_order = np.argsort(word_tfidf)

    # id2word = vectorizer.get_feature_names()
    
    # with open(save_path, "w", encoding='utf-8') as fw:
    #     for idx in word_order:
    #         w = id2word[idx]
    #         string = w + "\n"
    #         try:
    #             fw.write(string)
    #         except:
    #             pass

if __name__ == '__main__':
    main()
