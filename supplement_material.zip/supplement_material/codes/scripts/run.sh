#!/usr/bin/env bash

data="$1"
model="$2"
hg_base_model="$3"

if [ -z "$data" ]
then
    data="ali_cco_hier"
fi

if [ "$data" == "ali_cco_concat" ]||[ "$data" == "ali_cco_hier" ]
then
    max_len=2000
    max_seq_len=100
    max_conv_len=100
else
    max_len=600
    max_seq_len=100
    max_conv_len=50
fi

if [ -z "$model" ]
then
    model="HiGraph"
fi

hb_base_model="cnn_lstm"
hg_base_model="bert"

if [ "$model" == "Bert" ]||([ "$model" == "HiGraph" ]&&[ -n "$hg_base_model" -a "$hg_base_model" == "bert" ])||([ "$model" == "HyBrid" ]&&[ -n "$hb_base_model" -a "$hb_base_model" == "bert" ])
then
    max_len=512
fi

if [ "$data" == "ali_cco_concat" ]||[ "$data" == "ali_cco_hier" ]
then
    if [ "$model" == "Bert" ]||([ "$model" == "HiGraph" ]&&[ -n "$hg_base_model" -a "$hg_base_model" == "bert" ])||([ "$model" == "HyBrid" ]&&[ -n "$hb_base_model" -a "$hb_base_model" == "bert" ])
    then
        eval_every=4000
    else
        eval_every=2000
    fi
else
    if [ "$model" == "Bert" ]||([ "$model" == "HiGraph" ]&&[ -n "$hg_base_model" -a "$hg_base_model" == "bert" ])||([ "$model" == "HyBrid" ]&&[ -n "$hb_base_model" -a "$hb_base_model" == "bert" ])
    then
        eval_every=1000
    else
        eval_every=300
    fi
fi


if [ "$model" == "Bert" ]||([ "$model" == "HiGraph" ]&&[ -n "$hg_base_model" -a "$hg_base_model" == "bert" ])||([ "$model" == "HyBrid" ]&&[ -n "$hb_base_model" -a "$hb_base_model" == "bert" ])
then
    if [ -n "$hg_base_model" -a "$hg_base_model" == "bert" ]||([ "$model" == "HyBrid" ]&&[ -n "$hb_base_model" -a "$hb_base_model" == "bert" ])
    then
        hg_hidden_size=768
    else
        hg_hidden_size=64
    fi
    n_epoch=5
    batch_size=8
    lr_rate="2e-5"
    max_grad_norm=1.0
else
    hg_hidden_size=64
    n_epoch=20
    batch_size=32
    lr_rate="5e-4"
    max_grad_norm=1.0
fi

python train.py \
  --data=${data} \
  --model=${model} \
  --max_len=${max_len} \
  --max_conv_len=${max_conv_len} \
  --max_seq_len=${max_seq_len} \
  --n_epoch=${n_epoch} \
  --batch_size=${batch_size} \
  --eval_every=${eval_every} \
  --lr_rate=${lr_rate} \
  --max_grad_norm=${max_grad_norm} \
  --hb_base_model=${hb_base_model} \
  --hg_model_type=HeterGraph \
  --hg_base_model=${hg_base_model} \
  --hg_hidden_size=${hg_hidden_size} \
  --feature_extract