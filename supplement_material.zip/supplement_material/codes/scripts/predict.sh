#!/usr/bin/env bash

data="$1"
model="$2"
hg_base_model="$3"
hg_hidden_size="$4"
batch_size="$6"

if [ ! $model ]
then
    model="HiGraph"
fi

if [ "$model" == "Bert" ]||([ "$model" == "HiGraph" ]&&[ -n "$hg_base_model" -a "$hg_base_model" == "bert" ])
then
    if [ -n "$hg_base_model" -a "$hg_base_model" == "bert" ]
    then
        default_hg_hidden_size=768
    else
        default_hg_hidden_size=256
    fi
    default_batch_size=8
else
    default_hg_hidden_size=256
    default_batch_size=64
fi

python train.py \
  --data=${data:-"china_mobile_hier"} \
  --model=${model} \
  --batch_size=${batch_size:-$default_batch_size} \
  --checkpoint=${checkpoint:-"result/china_mobile_hier/HiGraph/2020-08-11_22.22.23/step_9000.pth"} \
  --hg_model_type=HeterGraph \
  --hg_graph_merge=serial \
  --hg_base_model=han \
  --hg_base_model2=bert \
  --bm2_hidden_size=768 \
  --hg_hidden_size=${hg_hidden_size:-$default_hg_hidden_size} \