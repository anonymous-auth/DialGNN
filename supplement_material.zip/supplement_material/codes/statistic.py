# coding = utf-8


import os

import matplotlib.pyplot as plt
from tqdm import tqdm

from utils import Log, pickle_load, read_text, write_text

# 设置matplotlib正常显示中文和负号
plt.rcParams['font.sans-serif']=['SimHei']   # 用黑体显示中文
plt.rcParams['axes.unicode_minus']=False     # 正常显示负号


def plot(data: dict, fig_title: str, fig_path: str, x_label: str, y_label: str, rotation=0, offset=10):
    """统计数据可视化

    Args:
        data (dict): 待可视化数据
        fig_size (tuple): 图片大小
        fig_title (str): 图片标题
        fig_path (str): 图片保存路径
    """
    plt.figure(figsize=(30, 30))
    if len(data) > 100: # 样本数过大
        data = {k: v for i, (k, v) in enumerate(data.items()) if i % offset == 0}

    plt.bar(range(len(data)), data.values(), align='center')
    plt.xlabel(x_label, fontsize=18)
    plt.ylabel(y_label, fontsize=18)
    plt.xticks(range(len(data)), data.keys(), rotation=rotation, fontsize=12)
    plt.yticks(fontsize=12)
    plt.title(fig_title, fontsize=20)
    Log.info("Save figure to: title = {}, path = {}".format(fig_title, fig_path))
    plt.savefig(fig_path, dpi=600, format='png')


def stat4concat(label_path, conv_path, statistic_path):
    if not os.path.exists(label_path):
        return
    
    Log.info("Statistic start: label_path = {}, conv_path = {}".format(label_path, conv_path))
    
    # 载入数据
    with open(label_path, 'r', encoding='utf-8') as fr1:
        label_list = [line.strip() for line in fr1]

    with open(conv_path, 'r', encoding='utf-8') as fr2:
        conv_list = ["".join(line.strip().split(" <eou> ")) for line in fr2]

    conv_len_list = []
    label_dict, conv_len_dict = dict(), dict()
    min_len, cnt = 600, 0

    for label in tqdm(label_list):
        label_dict[label] = label_dict.get(label, 0) + 1
    
    for conv in tqdm(conv_list):
        conv_len = len(conv)
        conv_len_list.append(conv_len)
        conv_len_dict[conv_len] = conv_len_dict.get(conv_len, 0) + 1
        if conv_len > min_len: cnt += 1

    Log.info("Max length of sequence: {}".format(max(conv_len_list)))
    Log.info("Ratio of length great than {} in conv: {}".format(min_len, cnt / len(conv_list)))
    # 按照文本长度排序
    conv_len_dict = dict(sorted(conv_len_dict.items(), key=lambda x: x[0]))
    
    plot(label_dict, '类别分布', os.path.join(statistic_path, 'label_dist_distribution.png'), 
            x_label='类别', y_label='样本数', rotation=90)
    plot(conv_len_dict, '未分词样本长度分布（拼接）', os.path.join(statistic_path, 'conv_len_distribution.png'), 
            x_label='长度', y_label='样本数', offset=100)


def stat4hier(conv_path, statistic_path):
    Log.info("Statistic start: conv_path = {}".format(conv_path))
    conv_len_list, seq_len_list = [], []
    conv_len_dict, seq_len_dict = dict(), dict()
    min_conv_len, min_seq_len = 50, 100
    cnt1, cnt2 = 0, 0
    
    with open(conv_path, 'r', encoding='utf-8') as fr1:
        conv_list = [line.strip() for line in fr1]

    conv_len_list = [len(conv.split(' <eou> ')) for conv in conv_list]
    
    for conv in conv_list:
        seq_list = conv.split(' <eou> ')
        seq_len_list += [len(seq) for seq in seq_list]

    for conv_len in tqdm(conv_len_list):
        conv_len_dict[conv_len] = conv_len_dict.get(conv_len, 0) + 1
        if conv_len > min_conv_len: cnt1 += 1

    for seq_len in tqdm(seq_len_list):
        seq_len_dict[seq_len] = seq_len_dict.get(seq_len, 0) + 1
        if seq_len > min_seq_len: cnt2 += 1
    
    conv_len_dict = dict(sorted(conv_len_dict.items(), key=lambda x: x[0]))
    seq_len_dict = dict(sorted(seq_len_dict.items(), key=lambda x: x[0]))

    Log.info("Maximum turn of conversation: {}".format(max(conv_len_list)))
    Log.info("Maximum length of sequence: {}".format(max(seq_len_list)))
    Log.info("Ratio of turn number great than {} in conv: {}".format(min_conv_len, cnt1 / len(conv_len_list)))
    Log.info("Ratio of sequence length great than {} in conv: {}".format(min_seq_len, cnt2 / len(seq_len_list)))

    plot(conv_len_dict, '轮数分布（未分词）', os.path.join(statistic_path, 'turn_num.png'), 
            x_label='轮数', y_label='样本数', offset=10)
    plot(seq_len_dict, '句子长度分布（未分词）', os.path.join(statistic_path, 'seq_len.png'), 
            x_label='长度', y_label='样本数', offset=20)


def cmp_bad_case(bad_case_path1, bad_case_path2, cmp_bad_case_path):
    """[summary]

    Args:
        bad_case_path1 ([type]): [description]
        bad_case_path2 ([type]): [description]
    """
    bad_case1_list = read_text(bad_case_path1)
    bad_case2_list = read_text(bad_case_path2)

    bad_case1_set = set(bad_case1_list)
    bad_case2_set = set(bad_case2_list)

    cmp_bad_case_list = list(bad_case1_set - bad_case2_set) # bad case just in model1
    write_text(cmp_bad_case_path, cmp_bad_case_list)


if __name__ == "__main__":
    label_path = "./data/china_mobile/concat/other/label.txt"
    conv_path = "./data/china_mobile/concat/other/conv.txt"
    statistic_path = "./statistic/china_mobile/concat"
    
    # label_path = "./data/ali_cco/concat/other/label.txt"
    # conv_path = "./data/ali_cco/concat/other/conv.txt"
    # statistic_path = "./statistic/ali_cco/concat"
    
    stat4concat(label_path, conv_path, statistic_path)

    # conv_path_hier = "./data/china_mobile/hier/other/conv.txt"
    # statistic_path_hier = "./statistic/china_mobile/hier"

    # conv_path_hier = "./data/ali_cco/hier/other/conv.txt"
    # statistic_path_hier = "./statistic/ali_cco/hier"

    # stat4hier(conv_path_hier, statistic_path_hier)

    # bad_case1_path = "./result/china_mobile_hier/HiGraph/bert_sent/bad_case.txt"
    # bad_case2_path = "./result/china_mobile_hier/HiGraph/bert_serial_sent/bad_case.txt"
    # cmp_bad_case_path = "./statistic/bert_bad_case.txt"
    # cmp_bad_case(bad_case1_path, bad_case2_path, cmp_bad_case_path)

    # bad_case1_path = "./result/china_mobile_hier/HiGraph/bert_serial_sent/bad_case.txt"
    # bad_case2_path = "./result/china_mobile_hier/HiGraph/bert_sent/bad_case.txt"
    # cmp_bad_case_path = "./statistic/bert_serial_sent_bad_case.txt"
    # cmp_bad_case(bad_case1_path, bad_case2_path, cmp_bad_case_path)
