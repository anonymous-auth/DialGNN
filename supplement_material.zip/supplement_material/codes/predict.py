# coding: UTF-8

import argparse
import os
import time
from importlib import import_module

import numpy as np
import pandas as pd
import torch
from sklearn import metrics
from tensorboardX import SummaryWriter
from torch.nn import CrossEntropyLoss
from torch.utils.data import DataLoader, SequentialSampler
from torch.utils.data._utils.collate import default_collate
from tqdm import tqdm
from transformers import BertTokenizer

from data_loader import (HeterGraphSet, HeterGraphSet2, IDDataSet,
                         IDDataSet_hier, load_and_cache_examples,
                         load_and_cache_examples_hier)
from train import evaluate
from utils import (Log, Vocab, f1_alpha_score, get_config, get_time_dif,
                   pickle_dump, pickle_load)

if __name__ == '__main__':

    test_config = get_config(mode='test')

    Log.info(test_config)
    with open(os.path.join(test_config.save_path, 'config.txt'), 'w') as f:
        print(test_config, file=f)

    vocab = Vocab()
    if not test_config.use_bert_vocab:
        vocab.load(test_config.word2id_path, test_config.id2word_path)
    else:
        tokenizer = BertTokenizer.from_pretrained(test_config.bert_pretrain_path)
        word2id = tokenizer.get_vocab()
        vocab.word2id = word2id
        vocab.id2word = {v: k for k, v in word2id.items()}
        vocab.vocab_size = len(word2id)
    
    test_config.vocab_size = vocab.vocab_size
    test_config.dropout = 0.0

    Log.info("Loading data...")
    start_time = time.time()
    
    if test_config.model.find('Bert') != -1:
        if test_config.data.find('concat') != -1:
            loader_fn = load_and_cache_examples
        else:
            loader_fn = load_and_cache_examples_hier
        
        test_dataset = loader_fn(args=test_config, 
                                  task=test_config.task, 
                                  tokenizer=tokenizer, 
                                  evaluate=False,
                                  predict=True)
        test_dataset.collate_fn = default_collate
    
    elif test_config.model.find('HiGraph') != -1:
        if test_config.hg_model_type == 'HeterGraph':
            dataset_fn = HeterGraphSet 
        elif test_config.hg_model_type == 'HeterGraph2':
            dataset_fn = HeterGraphSet2
        dataset_fn = HeterGraphSet if test_config.hg_model_type == 'HeterGraph' else HeterGraphSet2
        
        test_dataset = dataset_fn(data_path=test_config.csv_path,
                                    max_len=test_config.max_len,
                                    max_conv_len=test_config.max_conv_len,
                                    sent_max_len=test_config.max_seq_len,
                                    w2s_path=test_config.hg_w2s_path,
                                    w2c_path=test_config.hg_w2c_path,
                                    filter_word_path=test_config.hg_filter_word_path,
                                    vocab=vocab,
                                    tokenizer=tokenizer,
                                    hg_base_model=test_config.hg_base_model)

    else:
        if test_config.data.find("concat") != -1:
            test_dataset = IDDataSet(label=pickle_load(test_config.label_path),
                                conv=pickle_load(test_config.conv_path), 
                                conv_len=pickle_load(test_config.conv_len_path))
            
        else:
            test_dataset = IDDataSet_hier(label=pickle_load(test_config.label_path),
                                            conv=pickle_load(test_config.conv_path),
                                            conv_len=pickle_load(test_config.conv_len_path),
                                            seq_len=pickle_load(test_config.seq_len_path))
            
    
    test_loader = DataLoader(dataset=test_dataset,
                              batch_size=test_config.batch_size,
                              shuffle=False,
                              collate_fn=test_dataset.collate_fn)
    
    model_name = test_config.model
    graph = import_module('models.' + model_name)
    if test_config.model.find("HiGraph") != -1:
        if test_config.hg_model_type == 'HeterGraph':
            model = graph.HeterGraph(test_config).to(test_config.device)
        else:
            model = graph.HeterGraph2(test_config).to(test_config.device)
    else:
        model = graph.Model(test_config).to(test_config.device)
    
    start_index = test_config.checkpoint.find('step_')
    end_index = test_config.checkpoint.find('.pth')
    cur_step = int(test_config.checkpoint[start_index + 5: end_index])
    model.load_state_dict(torch.load(test_config.checkpoint))

    loss_func = CrossEntropyLoss()
    writer = SummaryWriter(log_dir=test_config.save_path)
    evaluate(model, test_loader, test_config, loss_func, writer, step=cur_step)
    writer.close()
