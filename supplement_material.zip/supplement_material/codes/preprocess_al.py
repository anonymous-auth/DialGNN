# coding = utf-8

import argparse
import json
import os
import re

import jieba
import numpy as np
from tqdm import tqdm

from utils import Log, write_text


def remove_stopwords(word_list: list, stopword_set: set):
    """去除停用词

    Args:
        word_list (list): [description]
        stopword_set (set): [description]

    Returns:
        [type]: [description]
    """
    if not word_list or not stopword_set:
        return word_list

    word_list = [word for word in word_list if word not in stopword_set]
    return word_list


def prepro_dataset(data_path, stopwords_path, label_dict_path, label_path, conv_path, speaker_path):
    """对源数据集进行分词处理，并同时将 label 转换为整数

    Args:
        data_path str: 源数据集路径
    """
    if not os.path.exists(data_path):
        Log.info("No invalid data: data_path = {}".format(data_path))
        return

    label_list = []
    label_dict = dict()
    conv_list, speaker_list = [], []
    with open(stopwords_path, 'r', encoding='utf-8') as fr1:
        stopwords_set = {line.strip() for line in fr1}
    
    # split user and service sent if necessary
    mode = 'all'
    if conv_path.find('user') != -1:
        mode = 'user'
    elif conv_path.find('service') != -1:
        mode = 'service'

    comp = re.compile('[^A-Z^a-z^0-9^\u4e00-\u9fa5]')

    with open(data_path, 'r', encoding='utf-8') as fr2:
        for line in tqdm(fr2):
            # 过滤空行
            line = line.strip()
            if not line: continue

            _, _, cur_data, level1_name, level2_name = line.split('\001')

            # parser data
            cur_data = "[" + cur_data + "]"
            cur_data_list = json.loads(cur_data)
            cur_conv_id_list = [int(d["id"]) for d in cur_data_list]
            cur_conv_list = [d["text"] for d in cur_data_list]
            
            # keep speaker id same with china mobile -> 1: service 2: user
            cur_speaker_list = [3 - int(d["member_type"]) for d in cur_data_list]

            # remove special token
            cur_conv_list = [comp.sub("", conv_text) for conv_text in cur_conv_list]
            
            # filter by empty text
            idx_list = [i for i, conv in enumerate(cur_conv_list) if len(conv) > 1]
            cur_conv_list = [cur_conv_list[idx] for idx in idx_list]
            cur_conv_id_list = [cur_conv_id_list[idx] for idx in idx_list]
            cur_speaker_list = [cur_speaker_list[idx] for idx in idx_list]

            # filter by speaker role
            idx_list = [i for i, speaker in enumerate(cur_speaker_list) if speaker in [1, 2]]
            cur_conv_list = [cur_conv_list[idx] for idx in idx_list]
            cur_conv_id_list = [cur_conv_id_list[idx] for idx in idx_list]
            cur_speaker_list = [cur_speaker_list[idx] for idx in idx_list]

            # sort
            cc_id_idx_list = np.argsort(np.array(cur_conv_id_list))
            cur_conv_list = [cur_conv_list[idx] for idx in cc_id_idx_list]
            cur_speaker_list = [str(cur_speaker_list[idx]) for idx in cc_id_idx_list]
            
            # preprocess label
            label = level1_name + '-' + level2_name
            if label not in label_dict:
                label_dict[label] = len(label_dict)
            label_list.append(label_dict[label])

            conv_list.append(" <eou> ".join(cur_conv_list))
            speaker_list.append(" ".join(cur_speaker_list))
    
    with open(label_dict_path, 'w', encoding='utf-8') as fw1:
        for k, v in label_dict.items():
            fw1.write(k + "\t" + str(v) +"\n")

    with open(label_path, 'w', encoding='utf-8') as fw2:
        for label in label_list:
            fw2.write(str(label) + '\n')
    
    write_text(conv_path, conv_list)
    write_text(speaker_path, speaker_list)


if __name__ == "__main__":
    data_path = "./data/ali_cco/cco_dialogue_data"
    
    stopwords_path = "./baidu_stopwords.txt"

    # label path
    label_dict_path = "./data/ali_cco/concat/other/label_dict.txt"
    label_path = "./data/ali_cco/concat/other/label.txt"
    
    conv_path = "./data/ali_cco/concat/other/conv.txt"
    speaker_path = "./data/ali_cco/concat/other/speaker.txt"

    prepro_dataset(data_path, stopwords_path, label_dict_path, label_path, conv_path, speaker_path)
