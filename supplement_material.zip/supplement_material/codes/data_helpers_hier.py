# coding = utf-8

import argparse
import os
import random

import numpy as np
import pandas as pd
from tqdm import tqdm
from transformers import BertTokenizer

from utils import Log, Vocab, pickle_dump, pickle_load


def split_dataset(label_list, speaker_list, conv_list, train_ratio=0.8, dev_ratio=0.1, shuffle=True):
    """划分数据集

    Args:
        label_list list: list of label
        text_list list: list of source text
        train_ratio float: ratio of train dataset. Defaults to 0.8.
        dev_ratio float: ratio of dev dataset. Defaults to False.

    Returns:
        tuple: train, dev, test
    """
    assert len(label_list) == len(conv_list), "样本数和标签数要保持一致"
    assert len(label_list) > 0, "样本数要大于0"
    assert train_ratio + dev_ratio < 1, "训练集和验证集样本和少于样本总数"

    num_samples = len(label_list)
    train_num_samples = int(num_samples * train_ratio)
    dev_num_samples = int(num_samples * (train_ratio + dev_ratio))

    Log.info("Split dataset start: num_samples = {}, train_ratio = {}, dev_ratio = {}, shuffle = {}".format(
        num_samples, train_ratio, dev_ratio, shuffle))

    # 划分数据集
    train = (label_list[:train_num_samples], speaker_list[:train_num_samples], conv_list[:train_num_samples])
    dev = (label_list[train_num_samples: dev_num_samples], speaker_list[train_num_samples: dev_num_samples], conv_list[train_num_samples: dev_num_samples])
    test = (label_list[dev_num_samples:], speaker_list[dev_num_samples:], conv_list[dev_num_samples:])
    
    return (train, dev, test)


def pad_dataset(conv_list: list, speaker_list: list, max_conv_len: int, max_seq_len: int, vocab: Vocab):
    """填充并转换为id

    Args:
        conv_list (list): source text list
        max_len (int): maximum length of one sample
        vocab (Vocab): Vocabulary

    Returns:
        tuple: (text_pad_list, text_len_list, seq_len_list)
    """
    def pad_sentence(idx_list: list, max_seq_len: int):
        n_valid_tokens = len(idx_list)
        idx_list = idx_list[:min(n_valid_tokens, max_seq_len)]
        n_pad = max_seq_len - len(idx_list)
        idx_list += [vocab.pad_id] * n_pad
        return idx_list

    assert len(conv_list) > 0

    conv_pad_list, speaker_pad_list, conv_len_list, seq_len_list = [], [], [], []
    Log.info("pad dataset start: num_samples = {}, max_conv_len = {}, max_seq_len = {}".format(
        len(conv_list), max_conv_len, max_seq_len))

    for sents, speakers in tqdm(zip(conv_list, speaker_list)):
        # truncate
        sents = sents[:max_conv_len]
        speakers = speakers[:max_conv_len]

        sents_idx_list = [vocab.sent2id(sent) for sent in sents]
        conv_len_list.append(len(sents_idx_list))
        cur_sent_len_list = [min(len(sent), max_seq_len) for sent in sents]
        seq_len_list.append(cur_sent_len_list)
        
        # pad
        seq_pad_list = [pad_sentence(sent_idx, max_seq_len) for sent_idx in sents_idx_list]
        conv_pad_list.append(seq_pad_list)
        speaker_pad_list.append(speakers)
    
    return (conv_pad_list, conv_len_list, seq_len_list, speaker_pad_list)


def save_dataset(prepro_data_path: str, data: tuple, data_type: str, vocab: Vocab, 
                   max_conv_len=50, max_seq_len=100):
    """存储data至指定路径（prepro_data_path + data_type）

    Args:
        prepro_data_path (str): str of preprocess data
        data (tuple): (label_list, text_list)
        data_type (str): train, dev or test
        vocab (Vocab): Vocabulary
        use_word (bool, optional): use word or not. Defaults to True.
        max_vocab_size (int, optional): maximum size of vocabulary. Defaults to 20000.
        max_conv_len (int, optional): maximum length of one conversation. Defaults to 50.
        max_seq_len (int, optional): maximum length of one sequence. Defaults to 50.
        min_freq (int, optional): minimum frequency of word. Defaults to 3.
    """
    label_list, conv_list, speaker_list = data
    
    data_path = os.path.join(prepro_data_path, data_type)
    if not os.path.exists(data_path):
        os.makedirs(data_path)
    
    csv_path = os.path.join(data_path, data_type + ".csv")
    label_path = os.path.join(data_path, "label.pkl")
    conv_path = os.path.join(data_path, 'conv.pkl')
    speaker_path = os.path.join(data_path, "speaker.pkl")
    conv_len_path = os.path.join(data_path, 'conv_len.pkl')
    seq_len_path = os.path.join(data_path, 'seq_len.pkl')
    
    Log.info(("Save dataset start: num_samples = {}, data_type: {}").format(len(label_list), data_type))

    conv_pad_list, conv_len_list, seq_len_list, speaker_pad_list = pad_dataset(conv_list, speaker_list, max_conv_len, max_seq_len, vocab)

    pickle_dump(label_list, label_path)
    pickle_dump(conv_pad_list, conv_path)
    pickle_dump(conv_len_list, conv_len_path)
    pickle_dump(seq_len_list, seq_len_path)
    pickle_dump(speaker_pad_list, speaker_path)

    conv_list = [" <eou> ".join(conv) for conv in conv_list]
    speaker_list = [" ".join(map(str, speaker)) for speaker in speaker_list]
    df = pd.DataFrame({'label': label_list, 'conv': conv_list, "speaker": speaker_list})
    df.to_csv(csv_path, sep='\t', index=False, encoding='utf-8')


def gen_dataset(prepro_data_path, vocab, max_conv_len=50, max_seq_len=100, train_ratio=0.8, dev_ratio=0.1, shuffle=True):
    """上下文拼接成一句话

    Args:
        src_data_path str: 源数据路径
        prepro_data_path ([type]): [description]
    """
    label_path = os.path.join(prepro_data_path, "label.txt")
    conv_path = os.path.join(prepro_data_path, "conv.txt")
    speaker_path = os.path.join(prepro_data_path, "speaker.txt")

    if not (os.path.exists(label_path) and os.path.exists(conv_path)):
        Log.info("No invalid data: label_path = {}, conv_path = {}".format(label_path, conv_path))
        return

    with open(label_path, 'r', encoding='utf-8') as fr1:
        label_list = [int(line.strip()) for line in fr1]
    
    with open(conv_path, 'r', encoding='utf-8') as fr2:
        conv_list = [line.strip().split(" <eou> ") for line in fr2]
    
    with open(speaker_path, 'r', encoding='utf-8') as fr3:
        speaker_list = [list(map(int, line.strip().split())) for line in fr3]

    # shuffle data
    if shuffle:
        for data in (label_list, conv_list, speaker_list):
            random.seed(4)
            random.shuffle(data)

    idx_list = [idx for idx, speaker in enumerate(speaker_list) if len(set(speaker)) == 2]
    label_list = [label_list[idx] for idx in idx_list]
    conv_list = [conv_list[idx] for idx in idx_list]
    speaker_list = [speaker_list[idx] for idx in idx_list]
    
    Log.info("Generate dataset start: label_path = {}, text_path = {}, train_ratio = {}, dev_ratio = {}".format(
        label_path, conv_path, train_ratio, dev_ratio))

    # 划分数据集并存储
    train, dev, test = split_dataset(label_list, conv_list, speaker_list)
    for data, data_type in zip([train, dev, test], ['train', 'dev', 'test']):
        save_dataset(prepro_data_path, data, data_type, vocab, max_conv_len=max_conv_len, max_seq_len=max_seq_len)


if __name__ == "__main__":
    # prepro_data_path = "./data/china_mobile/hier/other"
    prepro_data_path = "./data/ali_cco/hier/other"
    bert_pretrain_path = "./pretrained_models/bert-base-chinese/vocab.txt"

    if prepro_data_path.find("ali_cco") != -1:
        max_conv_len = 100
        max_seq_len = 100
    else:
        max_conv_len = 50
        max_seq_len = 100

    tokenizer = BertTokenizer.from_pretrained(bert_pretrain_path)
    word2id = tokenizer.get_vocab()
    vocab = Vocab()
    vocab.word2id = word2id
    vocab.id2word = {v: k for k, v in word2id.items()}
    vocab.vocab_size = len(word2id)

    gen_dataset(prepro_data_path, max_conv_len=max_conv_len, max_seq_len=max_seq_len, vocab=vocab)
