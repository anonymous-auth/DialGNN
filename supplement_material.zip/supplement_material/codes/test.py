# coding = utf-8

import os
import random
import re

import pandas as pd
import torch
import torch.nn as nn

from utils import pickle_load, Vocab

a = "你好啊, !我是张路，她是小胖fdsfsdf"
comp = re.compile('[^A-Z^a-z^0-9^\u4e00-\u9fa5]')
b = comp.sub("", a)
print(b)