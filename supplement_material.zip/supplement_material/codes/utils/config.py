# coding = utf-8

import argparse
import os
import pprint
import time
from datetime import datetime
from pathlib import Path

import torch
from transformers import BertModel

from .io_helpers import pickle_load

project_dir = Path(__file__).resolve().parent.parent
data_dir = project_dir.joinpath('data')
data_dict = {'china_mobile_concat': data_dir.joinpath('china_mobile', 'concat'), 'china_mobile_hier': data_dir.joinpath('china_mobile', 'hier'),
            'ali_cco_concat': data_dir.joinpath('ali_cco', 'concat'), 'ali_cco_hier': data_dir.joinpath('ali_cco', 'hier')}
save_dir = project_dir.joinpath('result')

class Config(object):
    def __init__(self, **kwargs):
        """Configuration Class: set kwargs as class attributes with setattr"""
        if kwargs is not None:
            for key, value in kwargs.items():
                setattr(self, key, value)

        self.device = torch.device('cuda' if torch.cuda.is_available() else 'cpu') # 设备
        self.n_speakers = 2

        # Dataset directory
        self.dataset_dir = data_dict[self.data]
        if self.model.find('Bert') != -1:
            self.dataset_dir = self.dataset_dir.joinpath('bert')
        elif self.model.find('Graph') != -1:
            self.dataset_dir = self.dataset_dir.joinpath('graph')
        else:
            self.dataset_dir = self.dataset_dir.joinpath('other')
        # Data Split ex) 'train', 'valid', 'test'
        self.data_dir = self.dataset_dir.joinpath(self.mode)
    
        # Pickled Vocabulary and embed_path
        # if not self.use_bert_vocab:
        #     self.word2id_path = self.dataset_dir.joinpath(prefix + 'word2id.pkl')
        #     self.id2word_path = self.dataset_dir.joinpath(prefix + 'id2word.pkl')

        if self.use_pretrain_embed:
            if self.use_bert_vocab:
                self.pretrain_embed = BertModel.from_pretrained(self.bert_pretrain_path).get_input_embeddings().weight
            # else:
            #     self.pretrain_embed = torch.tensor(pickle_load(prefix + 'embed.pkl'), dtype=torch.float32)
            self.word_dim = self.pretrain_embed.size(-1)

        num_cls_path = self.dataset_dir.joinpath('label_dict.txt')
        self.label_dict = {x.split('\t')[0]: int(x.split('\t')[1]) for x in open(num_cls_path, 'r', encoding='utf-8').readlines()}
        self.num_classes = len(self.label_dict)

        self.csv_path = self.data_dir.joinpath(self.mode + ".csv")
        
        # other model
        if self.model.find('Graph') == -1 and self.model.find('Bert') == -1:
            self.label_path = self.data_dir.joinpath('label.pkl')
            self.speaker_path = self.data_dir.joinpath('speaker.pkl')
            self.conv_text_path = self.data_dir.joinpath('conv.txt')
            self.conv_path = self.data_dir.joinpath('conv.pkl')
            self.conv_len_path = self.data_dir.joinpath('conv_len.pkl')
            if self.data.find("hier") != -1:
                self.seq_len_path = self.data_dir.joinpath("seq_len.pkl")

        # for bert model
        elif self.model.find('Bert') != -1:
            self.user_csv_path = self.data_dir.joinpath("user_" + self.mode + ".csv")
            self.service_csv_path = self.data_dir.joinpath("user_" + self.mode + ".csv")

        # for hetergraph model
        else:
            self.hg_filter_word_path = self.dataset_dir.joinpath('filter_words.txt')
            self.hg_w2c_path = self.data_dir.joinpath(self.mode + '.w2c.tfidf.json')
            w2s_path_suffix = '.w2s.tfidf.json' if self.hg_model_type == 'HeterGraph' else '.w2us.tfidf.json'
            self.hg_w2s_path = self.data_dir.joinpath(self.mode + w2s_path_suffix)

        # Save path
        if self.checkpoint:
            assert os.path.exists(self.checkpoint)
            self.save_path = os.path.dirname(self.checkpoint)
            self.bad_case_path = os.path.join(self.save_path, 'bad_case.txt')
            self.bad_case_csv_path = os.path.join(self.save_path, 'bad_case.csv')
        
        elif self.mode == "train" and not self.checkpoint:
            time_now = time.strftime('%Y-%m-%d_%H.%M.%S')
            self.save_path = save_dir.joinpath(self.data, self.model, time_now)
            self.bad_case_path = self.save_path.joinpath('bad_case.txt')
            self.bad_case_csv_path = self.save_path.joinpath('bad_case.csv')
            os.makedirs(self.save_path, exist_ok=True)     

    def __str__(self):
        """Pretty-print configurations in alphabetical order"""
        config_str = 'Configurations\n'
        config_str += pprint.pformat(self.__dict__)
        return config_str


def get_config(parse=True, **optional_kwargs):
    """
    Get configurations as attributes of class
    1. Parse configurations with argparse.
    2. Create Config class initilized with parsed kwargs.
    3. Return Config class.
    """
    parser = argparse.ArgumentParser(description='Text Classification')

    parser.add_argument('--no_cuda', action='store_true', default=False, help='does not use GPU')
    
    # Data
    parser.add_argument('--data', type=str, default='china_mobile_hier')
    parser.add_argument('--max_len', type=int, default=512)
    parser.add_argument('--max_conv_len', type=int, default=50)
    parser.add_argument('--max_seq_len', type=int, default=100)    

    # Mode
    parser.add_argument('--mode', type=str, default='train')

    parser.add_argument('--model', type=str, default='HiGraph', help='Choose a model')
    parser.add_argument('--checkpoint', type=str, default=None)

    # vocab
    parser.add_argument('--use_bert_vocab', action='store_true', default=True, help='Use bert vocabulary')

    # Train
    parser.add_argument('--n_epoch', type=int, default=5)
    parser.add_argument('--batch_size', type=int, default=8)

    # Utility
    parser.add_argument('--print_every', type=int, default=100)
    parser.add_argument('--eval_every', type=int, default=500)
    
    # optimizer
    parser.add_argument('--lr_rate', type=float, default=2e-5)
    parser.add_argument('--warmup_proportion', type=float, default=0.1)
    parser.add_argument('--max_grad_norm', type=float, default=1.0)
    parser.add_argument('--dropout', type=float, default=0.1)
    parser.add_argument("--adam_epsilon", default=1e-8, type=float,
                        help="Epsilon for Adam optimizer.")
    parser.add_argument("--weight_decay", default=0.0, type=float,
                        help="Weight decay if we apply some.")
    
    # word embedding
    parser.add_argument('--use_pretrain_embed', action="store_true", default=True)
    parser.add_argument('--word_dim', type=int, default=300)

    # cnn params
    parser.add_argument('--num_filters', type=int, default=64)
    parser.add_argument('--filter_size', type=list, default=[3,4,5])

    # Hybrid params
    parser.add_argument('--hb_base_model', type=str, default="han")

    # capsule params
    parser.add_argument('--capsule_num_filters', type=int, default=160)
    parser.add_argument('--capsule_filter_size', type=int, default=3)
    parser.add_argument('--num_capsules', type=int, default=10)
    parser.add_argument('--capsule_dim', type=int, default=16)

    # mfcnn params
    parser.add_argument('--mfcnn_filter_size', type=list, default=[1,2,3,4])

    # rnn params
    parser.add_argument('--num_layers', type=int, default=1)
    parser.add_argument('--hidden_dim1', type=int, default=128)
    parser.add_argument('--hidden_dim2', type=int, default=128)

    # attention params
    parser.add_argument('--att_hidden_dim', type=int, default=256)

    # transformer params
    parser.add_argument('--num_blocks', type=int, default=2)
    parser.add_argument('--num_head', type=int, default=5)
    parser.add_argument('--d_ff', type=int, default=300*4)

    # han params
    parser.add_argument("--word_rnn_size", type=int, default=128)
    parser.add_argument("--sentence_rnn_size", type=int, default=128)
    
    parser.add_argument("--word_rnn_layers", type=int, default=1)
    parser.add_argument("--sentence_rnn_layers", type=int, default=1)
    
    parser.add_argument("--word_att_size", type=int, default=256)
    parser.add_argument("--sentence_att_size", type=int, default=256)

    # fc graph params
    parser.add_argument('--fg_base_model', type=str, default='bert', help='Base model for Graph')
    parser.add_argument('--sum_bert_graph', action='store_true', default=False, help='Sum bert in graph')
    parser.add_argument('--nodal-attention', action='store_true', default=True, help='whether to use nodal attention in graph model: Equation 4,5,6 in Paper')
    parser.add_argument('--attention', default='general', help='Attention type in DialogRNN model')
    parser.add_argument('--windowp', type=int, default=5, help='context window size for constructing edges in graph model for past utterances')
    parser.add_argument('--windowf', type=int, default=5, help='context window size for constructing edges in graph model for future utterances')
    
    parser.add_argument("--D_w", default=300, type=int)
    parser.add_argument("--D_m", default=100, type=int)
    parser.add_argument("--D_g", default=150, type=int)
    parser.add_argument("--D_p", default=150, type=int)
    parser.add_argument("--D_e", default=100, type=int)
    parser.add_argument("--D_h", default=100, type=int)
    parser.add_argument("--D_a", default=100, type=int)
    parser.add_argument("--graph_h", default=100, type=int)

    # heter graph params
    parser.add_argument('--feature_extract', action='store_true', default=False, help='whether use hgraph')
    parser.add_argument('--hg_model_type', type=str, default='HeterGraph', help='model structure')
    
    parser.add_argument('--hg_base_model', type=str, default="cnn_lstm", help='Base model of HeterGraph')
    parser.add_argument('--hg_bm_pretrain_path', type=str, default=None, help='Pretrain model path of base model')
    
    parser.add_argument('--hg_n_iter', type=int, default=1, help='iteration hop [default: 1]')
    parser.add_argument('--hg_n_layers', type=int, default=1, help='Number of GAT layers [default: 1]')

    parser.add_argument('--hg_feat_embed_size', type=int, default=100, help='feature embedding size [default: 50]')
    
    parser.add_argument('--hg_num_filters', type=int, default=64, help='Number of cnn feat size [default: 64]')
    parser.add_argument('--hg_filter_size', type=list, default=[3,4,5], help='List of cnn filter size [default: [3, 4, 5]]')

    parser.add_argument('--hg_hidden_size', type=int, default=64, help='hidden size [default: 64]')
    parser.add_argument('--hg_lstm_hidden_state', type=int, default=128, help='size of lstm hidden state [default: 128]')
    parser.add_argument('--hg_lstm_layers', type=int, default=2, help='Number of lstm layers [default: 2]')
    parser.add_argument('--hg_n_feature_size', type=int, default=128, help='size of node feature [default: 128]')
    
    parser.add_argument('--hg_ffn_inner_hidden_size', type=int, default=1024, help='PositionwiseFeedForward inner hidden size [default: 512]')
    parser.add_argument('--hg_n_head', type=int, default=8, help='multihead attention number [default: 8]')
    
    parser.add_argument('--hg_recurrent_dropout_prob', type=float, default=0.1, help='recurrent dropout prob [default: 0.1]')
    parser.add_argument('--hg_atten_dropout_prob', type=float, default=0.1, help='attention dropout prob [default: 0.1]')
    parser.add_argument('--hg_ffn_dropout_prob', type=float, default=0.1,help='PositionwiseFeedForward dropout prob [default: 0.1]')
    
    parser.add_argument('--use_orthnormal_init', action='store_true', default=True, help='use orthnormal init for lstm [default: True]')
    parser.add_argument('--hg_update', type=int, default=1, help='How to update user service graph')

    parser.add_argument('--bert_model_type', type=str, default='bert')
    parser.add_argument('--bert_model_name_or_path', type=str, default='bert')
    parser.add_argument('--bert_pretrain_path', type=str, default='./pretrained_models/bert-base-chinese/')
    parser.add_argument("--bert_hidden_size", default=768, type=int,
                        help="Hidden size of bert.")

    # Parse arguments
    if parse:
        kwargs = parser.parse_args()
    else:
        kwargs = parser.parse_known_args()[0]

    # Namespace => Dictionary
    kwargs = vars(kwargs)
    kwargs.update(optional_kwargs)

    return Config(**kwargs)
