# coding = utf-8

import time
from datetime import timedelta

def f1_alpha_score(prec_score: float, recall_score: float, alpha=1.2):
    factor = alpha ** 2
    return ((1 + factor) * prec_score * recall_score) / (factor * prec_score + recall_score)

def get_time_dif(start_time):
    """获取已使用时间"""
    end_time = time.time()
    time_dif = end_time - start_time
    return timedelta(seconds=int(round(time_dif)))
