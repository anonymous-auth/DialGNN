# coding=utf-8

from collections import defaultdict
import pickle

import torch
from nltk import FreqDist
from torch import Tensor
from torch.autograd import Variable

from utils import pickle_load, pickle_dump

FILTER_BERT_ID_LIST = [0, 97, 98, 99, 100, 101, 102]
FILTER_BERT_TOKEN_LIST = ['[PAD]', '[SENT]', '[SERVICE]', '[USER]', '[UNK]', '[CLS]', '[SEP]']
PAD_ID, SENT_ID, SERVICE_ID, USER_ID, UNK_ID, CLS_ID, SEP_ID = FILTER_BERT_ID_LIST
PAD_TOKEN, SENT_TOKEN, SERVICE_TOKEN, USER_TOKEN, UNK_TOKEN, CLS_TOKEN, SEP_TOKEN = FILTER_BERT_TOKEN_LIST

class Vocab(object):
    def __init__(self):
        super().__init__()
    
        self.vocab_size = 0
        self.freqdist = FreqDist()
        self.pad_id, self.unk_id = PAD_ID, UNK_ID
        self.pad_token, self.unk_token = PAD_TOKEN, UNK_TOKEN

    def update(self, max_size=None, min_freq=1):
        """Initialize word2id based on self.freqdist
        """

        # {0: '<pad>', 1: '<unk>'}
        self.id2word = {
            self.pad_id: self.pad_token, self.unk_id: self.unk_token,
        }
        # {'<pad>': 0, '<unk>': 1}
        self.word2id = defaultdict(lambda: self.unk_id)  # Not in vocab => return UNK
        self.word2id.update({
            self.pad_token: self.pad_id, self.unk_token: self.unk_id
        })

        vocab_size = 2
        min_freq = max(min_freq, 1)

        # Reset frequencies of special tokens
        # [...('<eos>', 0), ('<pad>', 0)]
        freqdist = self.freqdist.copy()
        special_freqdist = {token: freqdist[token]
                            for token in [self.pad_token, self.unk_token]}
        freqdist.subtract(special_freqdist)

        # Sort: by frequency, then alphabetically
        # Ex) freqdist = { 'a': 4,   'b': 5,   'c': 3 }
        #  =>   sorted = [('b', 5), ('a', 4), ('c', 3)]
        sorted_frequency_counter = sorted(freqdist.items(), key=lambda k_v: k_v[0])
        sorted_frequency_counter.sort(key=lambda k_v: k_v[1], reverse=True)

        for word, freq in sorted_frequency_counter:

            if freq < min_freq or vocab_size == max_size:
                break
            self.id2word[vocab_size] = word
            self.word2id[word] = vocab_size
            vocab_size += 1

        self.vocab_size = vocab_size

    def __len__(self):
        return len(self.word2id)

    def load(self, word2id_path=None, id2word_path=None):
        if word2id_path:
            with open(word2id_path, 'rb') as f:
                word2id = pickle.load(f)
            # Can't pickle lambda function
            self.word2id = defaultdict(lambda: self.unk_id)
            self.word2id.update(word2id)
            self.vocab_size = len(self.word2id)

        if id2word_path:
            with open(id2word_path, 'rb') as f:
                id2word = pickle.load(f)
            self.id2word = id2word
    
    def save(self, word2id_path, id2word_path):
        with open(word2id_path, 'wb') as f:
            pickle.dump(dict(self.word2id), f)

        with open(id2word_path, 'wb') as f:
            pickle.dump(self.id2word, f)

    def add_word(self, word):
        assert isinstance(word, str), 'Input should be str'
        self.freqdist.update([word])

    def add_text(self, text):
        for word in text:
            self.add_word(word)

    def add_texts(self, texts):
        for text in texts:
            self.add_text(text)

    def to_list(self, list_like):
        """Convert list-like containers to list"""
        if isinstance(list_like, list):
            return list_like

        elif isinstance(list_like, Tensor):
            return list(list_like.numpy())

    def id2sent(self, id_list):
        """list of id => list of tokens (Single sentence)"""
        id_list = self.to_list(id_list)
        sentence = []
        for id in id_list:
            word = self.id2word[id]
            if word != self.pad_id:
                sentence.append(word)
        return sentence

    def sent2id(self, text):
        """list of tokens => list of id (Single sentence)"""
        id_list = [self.word2id[word] if word in self.word2id.keys() else self.unk_id for word in text]
        return id_list

    def decode(self, id_list):
        sentence = self.id2sent(id_list)
        return ' '.join(sentence)
