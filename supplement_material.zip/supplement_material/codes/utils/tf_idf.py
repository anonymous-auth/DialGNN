# coding = utf-8

from sklearn.feature_extraction.text import CountVectorizer, TfidfTransformer

class TfIdf(object):
    def __init__(self):
        super().__init__()

    def get_tfidf_embedding(self, text):
        """
        
        :param text: list, sent_number * word
        :return: 
            vectorizer: 
                vocabulary_: word2id
                get_feature_names(): id2word
            tfidf: array [sent_number, max_word_number]
        """
        vectorizer = CountVectorizer(lowercase=True, token_pattern='\\b\\w+\\b')
        word_count = vectorizer.fit_transform(text)
        tfidf_transformer = TfidfTransformer()
        tfidf = tfidf_transformer.fit_transform(word_count)
        tfidf_weight = tfidf.toarray()
        return vectorizer, tfidf_weight

    def compress_array(self, a, id2word):
        """
        
        :param a: matrix, [N, M], N is document number, M is word number
        :param id2word: word id to word
        :return: 
        """
        d = {}
        for i in range(len(a)):
            d[i] = {}
            for j in range(len(a[i])):
                if a[i][j] != 0:
                    d[i][id2word[j]] = a[i][j]
        return d

    def get_tfidfvector(self, text):
        if not text: return None

        cntvector, tfidf_weight = self.get_tfidf_embedding(text)
        
        id2word = {}
        for w, tfidf_id in cntvector.vocabulary_.items():   # word -> tfidf matrix row number
            id2word[tfidf_id] = w
        
        tfidfvector = self.compress_array(tfidf_weight, id2word)
        return tfidfvector
