# coding = utf-8

import os
import logging
from datetime import datetime
from pathlib import Path

project_dir = Path(__file__).resolve().parent.parent
log_dir = project_dir.joinpath('log')
if not log_dir.exists():
    log_dir.mkdir()

time_now = datetime.now().strftime('%Y-%m-%d_%H.%M.%S')
log_path = log_dir.joinpath(time_now + '.log')


def _get_log(log_path='./log/test.log'):
    logging.basicConfig(level=logging.INFO,
                format='[%(asctime)s %(filename)s [line:%(lineno)d]] %(levelname)s %(message)s',
                datefmt='%a, %d %b %Y %H:%M:%S',
                filename=log_path,
                filemode='w')
    return logging.getLogger()


def file_exists(func):
    """
    """
    def wrapper(path):
        if not os.path.exists(path):
            Log.info("invalid path: path = {}".format(path))
            return None
        Log.info('load start: path = {}'.format(path))
        return func(path)
    return wrapper

Log = _get_log(log_path)
