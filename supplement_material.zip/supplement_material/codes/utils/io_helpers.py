# coding = utf-8

import csv
import json
import os
import pickle
import sys

from .log_helpers import Log, file_exists


@file_exists
def pickle_load(path):
    """Load pickle file
    Args:
        path: str path of data
    Returns:
        data: object pickle data
    """
    with open(path, 'rb') as f:
        data = pickle.load(f)
    
    return data


def pickle_dump(data, path):
    """dump pickle data to disk
    
    Args:
        data: object pickle data
        path: str path of data
    """
    Log.info("dump pickle data: path = {}".format(path))
    with open(path, 'wb') as f:
        pickle.dump(data, f)


@file_exists
def read_json(path):
    with open(path, encoding="utf-8") as f:
        data = [json.loads(line) for line in f]
    return data


@file_exists
def read_text(path):
    with open(path, encoding="utf-8") as f:
        data = [line.strip() for line in f]
    return data

def write_text(path, data):
    with open(path, 'w', encoding="utf-8") as f:
        for d in data:
            f.write(d + '\n')

@file_exists
def read_csv(path, quotechar=None):
    """Reads a tab/comma separated value file.
        
    将数据以每行的形式转换为lines tuple
    """

    with open(path, "r", encoding="utf-8-sig") as f:
        next(f)
        reader = csv.reader(f, delimiter="\t", quotechar=quotechar)
        lines = []
        for line in reader:
            lines.append(line)
        return lines
