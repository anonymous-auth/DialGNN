# coding: UTF-8

import argparse
import csv
import os
import time
from importlib import import_module

import numpy as np
import pandas as pd
import torch
from sklearn import metrics
from tensorboardX import SummaryWriter
from torch.nn import CrossEntropyLoss
from torch.nn.utils import clip_grad_norm_
from torch.utils.data import DataLoader, SequentialSampler
from torch.utils.data._utils.collate import default_collate
from tqdm import tqdm
from transformers import (AdamW, BertConfig, BertTokenizer,
                          get_linear_schedule_with_warmup)

from data_loader import (HeterGraphSet, HeterGraphSet2, IDDataSet,
                         IDDataSet_hier, load_and_cache_examples,
                         load_and_cache_examples_hier)
from utils import (Log, Vocab, f1_alpha_score, get_config, get_time_dif,
                   pickle_dump, pickle_load)


def evaluate(model, dev_loader, dev_config, loss_func, writer, step):
    model.eval()
    loss = 0
    label_arr = np.array([], dtype=int)
    pred_arr = np.array([], dtype=int)
    mode = dev_config.mode
    
    Log.info("Evaluate model start...")
    with torch.no_grad():
        for data in tqdm(dev_loader):
            num = len(data)

            if not dev_config.no_cuda:
                if data[-1] is not None:
                    last_inp = data[-1].to(dev_config.device) if dev_config.model == "HiGraph" else data[-1].cuda()
                else:
                    last_inp = None
                data = [d.cuda() if d is not None else None for d in data[:-1]]
                data += [last_inp]

            labels = data[0]
            inp = data[1:]
            outputs = model(inp)
            
            loss += loss_func(outputs, labels)
            label_arr = np.append(label_arr, labels.cpu().numpy())
            pred = torch.max(outputs, 1)[1].cpu().numpy()
            pred_arr = np.append(pred_arr, pred)
    
    if mode == 'test':
        label_dict_ = {v: k for k, v in dev_config.label_dict.items()}
        bad_case_list = [(i, label_dict_.get(label), label_dict_.get(pred)) 
                            for i, (cmp_res, label, pred) in enumerate(zip(label_arr != pred_arr, label_arr, pred_arr)) if cmp_res]

        bad_df = pd.DataFrame(index=label_dict_.values(), columns=label_dict_.values()).fillna(0)
        for (bad_case_id, label, pred) in bad_case_list:
            bad_df.loc[label, pred] += 1

        bad_df.to_csv(dev_config.bad_case_csv_path, encoding='utf-8')

        with open(dev_config.csv_path, 'r', encoding="utf-8-sig") as fr:
            next(fr)
            reader = csv.reader(fr, delimiter="\t")
            conv_list = [line[1] for line in reader]
        
        with open(dev_config.bad_case_path, 'w', encoding='utf-8') as fw:
            for (bad_case_id, label, pred) in bad_case_list:
               fw.write("Real: {}, Predict: {}, Sample: {}\n".format(label, pred, conv_list[bad_case_id]))

    loss /= len(dev_loader)
    acc = metrics.accuracy_score(label_arr, pred_arr)
    prec = metrics.precision_score(label_arr, pred_arr, average='macro')
    recall = metrics.recall_score(label_arr, pred_arr, average='macro')
    f1 = metrics.f1_score(label_arr, pred_arr, average='macro')
    f1_alpha = f1_alpha_score(prec, recall)

    writer.add_scalar("loss/" + mode, loss, step)
    writer.add_scalar("acc/" + mode, acc, step)
    writer.add_scalar("prec/" + mode, prec, step)
    writer.add_scalar("recall/" + mode, recall, step)
    writer.add_scalar("f1/" + mode, f1, step)
    writer.add_scalar("f1_alpha/" + mode, f1_alpha, step)
    
    Log.info(('Step: {}, Loss: {:.3f}, Acc: {:.3f}, Prec: {:.3f}, Recall: {:.3f}, ' + 
            'F1: {:3f}, F1 alpha: {:.3f}').format(step, loss, acc, prec, recall, f1, f1_alpha))

    # if mode == 'dev':
    model_path = os.path.join(dev_config.save_path, 'step_' + str(step) + '.pth')
    Log.info('Save model start: model_path = {}'.format(model_path))
    torch.save(model.state_dict(), model_path)

    return f1_alpha


def train(model, train_loader, dev_loader, train_config, dev_config, loss_func, writer):
    start_time = time.time()

    num_train_steps = len(train_loader) * train_config.n_epoch
    num_warmup_steps = int(num_train_steps * train_config.warmup_proportion)
    Log.info("num_train_steps = {}, num_warmup_steps = {}".format(num_train_steps, num_warmup_steps))

    optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr=train_config.lr_rate)
    scheduler = get_linear_schedule_with_warmup(optimizer, num_warmup_steps=num_warmup_steps, num_training_steps=num_train_steps)
    
    optimal_score = 0
    early_stop = 0  # 记录上次验证集loss下降的batch数
    stop_flag = False

    cur_step = 0
    if train_config.checkpoint:
        start_index = train_config.checkpoint.find('step_')
        end_index = train_config.checkpoint.find('.pth')
        cur_step = int(train_config.checkpoint[start_index + 5: end_index])
    start_epoch = cur_step // len(train_loader)  # 记录进行到多少batch
    Log.info('Train model start...')
    model.train()
    
    for epoch in range(start_epoch, train_config.n_epoch):
        Log.info('Epoch [{}/{}]'.format(epoch + 1, train_config.n_epoch))
        for data in tqdm(train_loader):
            cur_step += 1
            if not train_config.no_cuda:
                if data[-1] is not None:
                    last_inp = data[-1].to(train_config.device) if train_config.model == "HiGraph" else data[-1].cuda()
                else: 
                    last_inp = None
                data = [d.cuda() if d is not None else None for d in data[:-1]]
                data += [last_inp]

            labels = data[0]
            inp = data[1:]
            outputs = model(inp)
            
            loss = loss_func(outputs, labels)
            loss.backward()
            clip_grad_norm_(model.parameters(), train_config.max_grad_norm)
            optimizer.step()
            scheduler.step()  # Update learning rate schedule
            model.zero_grad()

            if cur_step % train_config.print_every == 0:
                true = labels.data.cpu().numpy()
                pred = torch.max(outputs, 1)[1].cpu().numpy()
                train_acc = metrics.accuracy_score(true, pred)
                train_p = metrics.precision_score(true, pred, average='macro')
                train_r = metrics.recall_score(true, pred, average='macro')
                train_f1 = metrics.f1_score(true, pred, average='macro')
                train_f1_alpha = f1_alpha_score(train_p, train_r)
                writer.add_scalar("loss/train", loss.item(), cur_step)
                writer.add_scalar("acc/train", train_acc, cur_step)
                Log.info(('Step: {}, Train Loss: {:.3f}, Train Acc: {:.3f}, Train Prec: {:.3f}, Train Recall: {:.3f}, '
                            'Train F1: {:.3f}, Train F1 alpha: {:.3f}').format(cur_step, loss.item(), train_acc, 
                                                                                train_p, train_r, train_f1, train_f1_alpha))
            # if cur_step % 1 == 0:
            if cur_step % train_config.eval_every == 0:
                # evaluate
                f1_alpha = evaluate(model, dev_loader, dev_config, loss_func, writer, cur_step)

                if optimal_score < f1_alpha:
                    optimal_score = f1_alpha
                    early_stop = 0
                else:
                    early_stop += 1

                if early_stop >= 10:
                    Log.info("No optimization for a long time, auto-stopping...")
                    stop_flag = True
                    break
                    
                model.train()
        
        if stop_flag: break

    # 最后一步还未检测
    if train_config.eval_every != 0 and not stop_flag:
        evaluate(model, dev_loader, dev_config, loss_func, writer, cur_step)

    Log.info('Time usage: {:.3f} secs'.format(time.time() - start_time))
    Log.info('Done!')


if __name__ == '__main__':
    train_config = get_config(mode='train')
    train_config.no_cuda = False if torch.cuda.is_available() and not train_config.no_cuda else True
    # dev_config = get_config(mode='dev')
    dev_config = get_config(mode='test')
    dev_config.no_cuda = train_config.no_cuda
    dev_config.save_path = train_config.save_path
    dev_config.bad_case_path = train_config.bad_case_path
    dev_config.bad_case_csv_path = train_config.bad_case_csv_path
    
    Log.info(train_config)
    Log.info("Evaluate mode: {}".format(dev_config.mode))
    with open(os.path.join(train_config.save_path, 'config.txt'), 'w', encoding="utf-8") as f:
        print(train_config, file=f)
    
    vocab = Vocab()
    if not train_config.use_bert_vocab:
        vocab.load(train_config.word2id_path, train_config.id2word_path)
    else:
        tokenizer = BertTokenizer.from_pretrained(train_config.bert_pretrain_path)
        word2id = tokenizer.get_vocab()
        vocab.word2id = word2id
        vocab.id2word = {v: k for k, v in word2id.items()}
        vocab.vocab_size = len(word2id)
    
    train_config.vocab_size = vocab.vocab_size
    dev_config.dropout = 0.0

    Log.info("Loading data...")
    start_time = time.time()
    
    if train_config.model.find('Bert') != -1 or (train_config.model == "HyBrid" and train_config.hb_base_model == "bert"):
        if train_config.data.find('concat') != -1:
            loader_fn = load_and_cache_examples
        else:
            loader_fn = load_and_cache_examples_hier
        
        train_dataset = loader_fn(args=train_config, 
                                  task=train_config.data, 
                                  tokenizer=tokenizer, 
                                  evaluate=False,
                                  predict=False)
        train_dataset.collate_fn = default_collate
        
        dev_dataset =  loader_fn(args=dev_config, 
                                  task=dev_config.data, 
                                  tokenizer=tokenizer, 
                                  evaluate=False,
                                  predict=True)
        dev_dataset.collate_fn = default_collate

    elif train_config.model.find('HiGraph') != -1:
        if train_config.hg_model_type == 'HeterGraph':
            dataset_fn = HeterGraphSet 
        elif train_config.hg_model_type == 'HeterGraph2':
            dataset_fn = HeterGraphSet2
        
        train_dataset = dataset_fn(data_path=train_config.csv_path,
                                    max_len=train_config.max_len,
                                    max_conv_len=train_config.max_conv_len,
                                    sent_max_len=train_config.max_seq_len,
                                    w2s_path=train_config.hg_w2s_path,
                                    w2c_path=train_config.hg_w2c_path,
                                    filter_word_path=train_config.hg_filter_word_path,
                                    vocab=vocab,
                                    tokenizer=tokenizer,
                                    hg_base_model=train_config.hg_base_model)

        dev_dataset = dataset_fn(data_path=dev_config.csv_path,
                                max_len=dev_config.max_len,
                                max_conv_len=dev_config.max_conv_len,
                                sent_max_len=dev_config.max_seq_len,
                                w2s_path=dev_config.hg_w2s_path,
                                w2c_path=dev_config.hg_w2c_path,
                                filter_word_path=dev_config.hg_filter_word_path,
                                vocab=vocab,
                                tokenizer=tokenizer,
                                hg_base_model=dev_config.hg_base_model)
    else:
        if train_config.data.find("concat") != -1:
            train_dataset = IDDataSet(label=pickle_load(train_config.label_path),
                                conv=pickle_load(train_config.conv_path), 
                                conv_len=pickle_load(train_config.conv_len_path))
            
            dev_dataset = IDDataSet(label=pickle_load(dev_config.label_path),
                                    conv=pickle_load(dev_config.conv_path), 
                                    conv_len=pickle_load(dev_config.conv_len_path))
        else:
            train_dataset = IDDataSet_hier(label=pickle_load(train_config.label_path),
                                            conv=pickle_load(train_config.conv_path),
                                            conv_len=pickle_load(train_config.conv_len_path),
                                            seq_len=pickle_load(train_config.seq_len_path))
            
            dev_dataset = IDDataSet_hier(label=pickle_load(dev_config.label_path),
                                            conv=pickle_load(dev_config.conv_path),
                                            conv_len=pickle_load(dev_config.conv_len_path),
                                            seq_len=pickle_load(dev_config.seq_len_path))
    
    train_loader = DataLoader(dataset=train_dataset,
                              batch_size=train_config.batch_size,
                              shuffle=False,
                              collate_fn=train_dataset.collate_fn)
    dev_loader = DataLoader(dataset=dev_dataset,
                              batch_size=dev_config.batch_size,
                              shuffle=False,
                              collate_fn=dev_dataset.collate_fn)
    
    time_dif = get_time_dif(start_time)
    Log.info("Time usage: {}".format(time_dif))

    model_name = train_config.model
    graph = import_module('models.' + model_name)
    if train_config.model == "HiGraph":
        if train_config.hg_model_type == 'HeterGraph':
            model = graph.HeterGraph(train_config)
        else:
            model = graph.HeterGraph2(train_config)
    else:
        model = graph.Model(train_config)

    if not train_config.no_cuda:
        model = model.to(train_config.device)

    if train_config.checkpoint:
        model.load_state_dict(torch.load(train_config.checkpoint))

    loss_func = CrossEntropyLoss()
    writer = SummaryWriter(log_dir=train_config.save_path)
    train(model, train_loader, dev_loader, train_config, dev_config, loss_func, writer)
    writer.close()
