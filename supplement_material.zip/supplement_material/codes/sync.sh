rsync -avrz --include="*/" --include="*.py" --include="*.sh" --exclude="*" root@47.96.89.89:/data/intent_classification/ /Users/zhanglu/Desktop/code/al/intent_classification/
